"""
Migration: Add @owner and @requester tokens to request_submitted templates
==========================================================================
The request_submitted notification previously only targeted role-based
recipients (e.g. Reviewing Officer), so the originator who submitted the
request never received a confirmation email.

This script adds "@owner" and "@requester" to the recipient_roles of all
three channels (email / sms / inapp) for the global request_submitted
template — so the originator is always CC'd on their own submission.

Idempotent — safe to run multiple times.
"""

from database import get_db
from models import NotificationTemplate


def migrate():
    db = next(get_db())
    try:
        templates = (
            db.query(NotificationTemplate)
            .filter(
                NotificationTemplate.event_type == "request_submitted",
                NotificationTemplate.organization_id.is_(None),  # global only
            )
            .all()
        )

        if not templates:
            print("[SKIP] No global request_submitted templates found.")
            return

        tokens_to_add = ["@owner", "@requester"]
        changed = 0

        for tmpl in templates:
            roles = list(tmpl.recipient_roles or [])
            added = []
            for token in tokens_to_add:
                if token not in roles:
                    roles.append(token)
                    added.append(token)

            if added:
                tmpl.recipient_roles = roles
                changed += 1
                print(
                    f"[UPDATE] {tmpl.channel:6} template (id={tmpl.id}) "
                    f"recipient_roles += {added}  =>  {roles}"
                )
            else:
                print(
                    f"[SKIP]   {tmpl.channel:6} template (id={tmpl.id}) "
                    f"already has @owner/@requester"
                )

        if changed:
            db.commit()
            print(f"\n[OK] Updated {changed} template(s).")
        else:
            print("\n[OK] Nothing to update - already up to date.")

    finally:
        db.close()


if __name__ == "__main__":
    migrate()
