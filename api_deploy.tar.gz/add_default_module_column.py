"""
Migration: Add default_module_id column to org_roles and role_templates tables
"""
from sqlalchemy import text
from database import get_db

def main():
    db = next(get_db())

    # Add column to org_roles
    print("Adding default_module_id to org_roles...")
    db.execute(text("""
        ALTER TABLE public.org_roles
        ADD COLUMN IF NOT EXISTS default_module_id INTEGER REFERENCES public.modules(id)
    """))

    # Add column to role_templates
    print("Adding default_module_id to role_templates...")
    db.execute(text("""
        ALTER TABLE public.role_templates
        ADD COLUMN IF NOT EXISTS default_module_id INTEGER REFERENCES public.modules(id)
    """))

    db.commit()

    # Get EE TLSS Dashboard module ID
    result = db.execute(text("SELECT id FROM public.modules WHERE path = 'ee_tlss_dashboard'")).fetchone()
    if not result:
        print("[WARN] EE TLSS Dashboard module not found. Skipping default module assignment.")
        return

    ee_tlss_dashboard_id = result[0]
    print(f"EE TLSS Dashboard module ID: {ee_tlss_dashboard_id}")

    # Update EE TLSS role template
    db.execute(text("""
        UPDATE public.role_templates
        SET default_module_id = :module_id
        WHERE name = 'EE TLSS'
    """), {"module_id": ee_tlss_dashboard_id})

    # Update EE TLSS org_roles for KPTCL
    result = db.execute(text("""
        UPDATE public.org_roles
        SET default_module_id = :module_id
        WHERE name = 'EE TLSS'
        RETURNING id, organization_id
    """), {"module_id": ee_tlss_dashboard_id})

    updated = result.fetchall()
    db.commit()

    print(f"Updated {len(updated)} EE TLSS org_roles with default module")
    print("Migration complete!")

if __name__ == "__main__":
    main()
