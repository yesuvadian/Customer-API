import os, sys, uuid
from datetime import datetime
os.chdir(r'C:\Yesu\CustomerAPI\Customer-API')
sys.path.insert(0, r'C:\Yesu\CustomerAPI\Customer-API')

from database import SessionLocal
from models import User, OrgRole, OrgUserRole, TesterLocation, Organization
from auth_utils import get_password_hash

db = SessionLocal()

# Get KPTCL org
org = db.query(Organization).filter(Organization.code == 'KPTCL').first()
if not org:
    org = db.query(Organization).filter(Organization.name.ilike('%Karnataka Power%')).first()
print(f'Org: {org.name} ({org.id})')

# Get SEE RT OrgRole for KPTCL
see_rt_role = db.query(OrgRole).filter(
    OrgRole.name == 'SEE RT',
    OrgRole.organization_id == org.id
).first()
print(f'SEE RT OrgRole: {see_rt_role.id}')

now = datetime.now(datetime.now().astimezone().tzinfo)

zone_testers = [
    {
        "email": "see.rt@kptcl.com",
        "firstname": "SEE", "lastname": "RT",
        "phone": "+91-9900000014",
        "employee_id": "KPTCL-SEE-RT-001",
        "zone": "Bangalore Zone", "ce_circle": "BMAZ North",
        "se_division": "Bangalore Urban Division", "ee_subdivision": "TL & SS Sub-Division 1",
    },
    {
        "email": "see.rt.bangalore@kptcl.com",
        "firstname": "SEE RT", "lastname": "Bangalore",
        "phone": "+91-9900000020",
        "employee_id": "KPTCL-SEE-RT-BLR-001",
        "zone": "Bangalore Zone", "ce_circle": "BMAZ South",
        "se_division": "Bangalore Rural Division", "ee_subdivision": "TL & SS Sub-Division 2",
    },
    {
        "email": "see.rt.hubli@kptcl.com",
        "firstname": "SEE RT", "lastname": "Hubli",
        "phone": "+91-9900000021",
        "employee_id": "KPTCL-SEE-RT-HBL-001",
        "zone": "Hubli Zone", "ce_circle": "O&M Zone Hubballi",
        "se_division": "Hubli Division", "ee_subdivision": "TL & SS Sub-Division 1",
    },
    {
        "email": "see.rt.mysore@kptcl.com",
        "firstname": "SEE RT", "lastname": "Mysore",
        "phone": "+91-9900000022",
        "employee_id": "KPTCL-SEE-RT-MYS-001",
        "zone": "Mysore Zone", "ce_circle": "Mysuru Zone",
        "se_division": "Mysuru Division", "ee_subdivision": "TL & SS Sub-Division 1",
    },
    {
        "email": "see.rt.gulbarga@kptcl.com",
        "firstname": "SEE RT", "lastname": "Gulbarga",
        "phone": "+91-9900000023",
        "employee_id": "KPTCL-SEE-RT-GLB-001",
        "zone": "Gulbarga Zone", "ce_circle": "Gulbarga Zone",
        "se_division": "Gulbarga Division", "ee_subdivision": "TL & SS Sub-Division 1",
    },
]

created = []
for t in zone_testers:
    user = db.query(User).filter_by(email=t["email"]).first()
    if not user:
        user = User(
            id=uuid.uuid4(),
            email=t["email"],
            password_hash=get_password_hash("admin123"),
            firstname=t["firstname"],
            lastname=t["lastname"],
            phone_number=t["phone"],
            employee_id=t["employee_id"],
            organization_id=org.id,
            isactive=True,
            email_confirmed=True,
            phone_confirmed=True,
            cts=now, mts=now,
        )
        db.add(user)
        db.flush()
        print(f'  [+] Created: {t["email"]}')
    else:
        print(f'  [=] Exists: {t["email"]} ({user.id})')

    # Assign SEE RT OrgRole
    existing_role = db.query(OrgUserRole).filter_by(
        user_id=user.id, org_role_id=see_rt_role.id, is_active=True
    ).first()
    if not existing_role:
        db.add(OrgUserRole(
            id=uuid.uuid4(),
            user_id=user.id,
            org_role_id=see_rt_role.id,
            department_id=None,
            is_active=True,
            assigned_at=now,
            assigned_by=None,
        ))
        print(f'       * OrgRole assigned')

    # Upsert TesterLocation
    loc = db.query(TesterLocation).filter_by(user_id=user.id).first()
    if not loc:
        db.add(TesterLocation(
            user_id=user.id,
            zone=t["zone"],
            ce_circle=t["ce_circle"],
            se_division=t["se_division"],
            ee_subdivision=t["ee_subdivision"],
            is_active=True,
        ))
        print(f'       * TesterLocation: {t["zone"]} / {t["ce_circle"]}')
    else:
        loc.zone = t["zone"]
        loc.ce_circle = t["ce_circle"]
        loc.se_division = t["se_division"]
        loc.ee_subdivision = t["ee_subdivision"]
        loc.is_active = True
        print(f'       * TesterLocation updated: {t["zone"]} / {t["ce_circle"]}')

    created.append(t["email"])

db.commit()

print('\n=== Created/Updated Zone Testers ===')
print(f'{"Email":40s}  {"Password":10s}  {"Zone":20s}')
print('-' * 80)
for t in zone_testers:
    print(f'{t["email"]:40s}  admin123    {t["zone"]}')

db.close()
print('\nDone.')
