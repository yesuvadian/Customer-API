"""
Add category_type column to CategoryDetails and populate from description
"""
from database import SessionLocal
from models import CategoryDetails
from sqlalchemy import text

def add_category_type_column():
    """Add category_type column and populate it"""
    db = SessionLocal()

    try:
        print("=" * 80)
        print("STEP 1: ADD category_type COLUMN")
        print("=" * 80)

        # Add column if not exists
        db.execute(text("""
            ALTER TABLE "CategoryDetails"
            ADD COLUMN IF NOT EXISTS category_type VARCHAR(50);
        """))
        db.commit()
        print("[OK] Column added\n")

        print("=" * 80)
        print("STEP 2: POPULATE category_type FROM description")
        print("=" * 80)

        # Get all CategoryDetails
        all_details = db.query(CategoryDetails).all()

        updated = 0
        for detail in all_details:
            desc_lower = (detail.description or "").lower()

            if "maintenance for" in desc_lower:
                detail.category_type = "maintenance"
                updated += 1
            elif "inspection for" in desc_lower:
                detail.category_type = "inspection"
                updated += 1
            elif "repair lifecycle for" in desc_lower:
                detail.category_type = "repair_lifecycle"
                updated += 1
            elif "test for" in desc_lower:
                detail.category_type = "test"
                updated += 1
            else:
                # Default to test if no match
                detail.category_type = "test"
                updated += 1

        db.commit()
        print(f"[OK] Updated {updated} records\n")

        print("=" * 80)
        print("STEP 3: VERIFY CATEGORIZATION")
        print("=" * 80)

        # Count by category
        test_count = db.query(CategoryDetails).filter(CategoryDetails.category_type == "test").count()
        maint_count = db.query(CategoryDetails).filter(CategoryDetails.category_type == "maintenance").count()
        insp_count = db.query(CategoryDetails).filter(CategoryDetails.category_type == "inspection").count()
        repair_count = db.query(CategoryDetails).filter(CategoryDetails.category_type == "repair_lifecycle").count()

        print(f"Test: {test_count}")
        print(f"Maintenance: {maint_count}")
        print(f"Inspection: {insp_count}")
        print(f"Repair Lifecycle: {repair_count}")
        print(f"Total: {test_count + maint_count + insp_count + repair_count}")

        print("\n" + "=" * 80)
        print("SUCCESS: category_type column added and populated")
        print("=" * 80)

    except Exception as e:
        print(f"\nERROR: {e}")
        db.rollback()
        raise
    finally:
        db.close()

if __name__ == "__main__":
    add_category_type_column()
