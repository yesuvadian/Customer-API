# Default Module Implementation Summary

## Overview
Implemented role-specific dashboard system using `default_module_id` instead of hard-coded `dashboard_type` logic.

## Backend Changes

### 1. Database Schema
**Tables Modified:**
- `org_roles` - Added `default_module_id INTEGER REFERENCES modules(id)`
- `role_templates` - Added `default_module_id INTEGER REFERENCES modules(id)`

**Migration Script:** `add_default_module_column.py`

### 2. Models (`models.py`)
**OrgRole model (line 329):**
```python
default_module_id = Column(Integer, ForeignKey("public.modules.id"), nullable=True)
```

**RoleTemplate model (line 417):**
```python
default_module_id = Column(Integer, ForeignKey("public.modules.id"), nullable=True)
```

Added relationship:
```python
default_module = relationship("Module", foreign_keys=[default_module_id])
```

### 3. Schemas (`schemas.py`)
**UserResponse (line 588):**
```python
default_module_path: Optional[str] = None  # Default module path to navigate on login
```

### 4. Login API (`routers/auth.py` lines 30-53)
Updated SQL query to fetch `default_module_path`:
```python
query = text("""
    SELECT oroles.default_dashboard_type, m.path
    FROM public.org_user_roles our
    JOIN public.org_roles oroles ON our.org_role_id = oroles.id
    LEFT JOIN public.modules m ON oroles.default_module_id = m.id
    WHERE our.user_id = :user_id AND our.is_active = true
    ORDER BY CASE oroles.default_dashboard_type
        WHEN 'admin' THEN 4
        WHEN 'supervisor' THEN 3
        WHEN 'field' THEN 2
        ELSE 1
    END DESC
    LIMIT 1
""")

result["user"]["default_module_path"] = default_module_path
```

### 5. Seed Data (`seed.py`)
**Module variable (line 1854):**
```python
ee_tlss_dashboard_module_id = modules_by_name.get("EE TLSS Dashboard")
```

**EE TLSS Role Template (line 2073):**
```python
{
    "name": "EE TLSS",
    "description": "Executive Engineer - Transmission Line & Substation primary reviewer",
    "default_dashboard_type": "supervisor",
    "default_module_id": ee_tlss_dashboard_module_id,  # ← NEW
    ...
}
```

**seed_role_templates function (lines 2180-2197):**
Updated to handle `default_module_id` field.

## Frontend Changes

### 1. Models (`lib/models/models.dart`)
**User class (line 94):**
```dart
String? defaultModulePath; // Default module path to navigate on login
```

**Constructor (line 108):**
```dart
this.defaultModulePath, // Default module path
```

**fromJson (line 137):**
```dart
defaultModulePath: json['default_module_path'],
```

**toJson (line 154):**
```dart
'default_module_path': defaultModulePath,
```

### 2. Dashboard (`lib/pages/zoho/dashboard.dart`)
Added TODO comment for implementing custom dashboard routing based on `defaultModulePath`.

Currently uses existing `dashboard_type` logic as fallback.

## How It Works

### Current Flow
1. User logs in
2. API returns:
   - `dashboard_type`: "supervisor"
   - `default_module_path`: "ee_tlss_dashboard" (for EE TLSS role)
3. Flutter receives both fields
4. Currently uses `dashboard_type` to show generic supervisor dashboard
5. **TODO**: Implement routing to custom dashboard based on `default_module_path`

### Future Flow (To Implement)
1. Check if `user.defaultModulePath` is not null
2. If yes, route to specific dashboard component:
   - `ee_tlss_dashboard` → EE TLSS Dashboard (rich monitoring KPIs)
   - `aee_dashboard` → AEE Dashboard
   - `cee_dashboard` → CEE Dashboard
   - etc.
3. If null, fall back to generic dashboard based on `dashboard_type`

## Module Assignment Examples

| Role | Default Module | Dashboard Path |
|------|---------------|----------------|
| EE TLSS | EE TLSS Dashboard | `ee_tlss_dashboard` |
| SEE W&M | (to be assigned) | null → generic supervisor |
| AEE Maintenance | (to be assigned) | null → generic supervisor |
| CEE Transmission Zone | (to be assigned) | null → generic supervisor |
| Admin | (to be assigned) | null → generic admin |
| Originator | (to be assigned) | null → generic field |

## Next Steps

### 1. Assign Default Modules to Other Roles
Update seed.py to assign dashboard modules:
```python
aee_dashboard_module_id = modules_by_name.get("AEE Dashboard")
see_dashboard_module_id = modules_by_name.get("SEE Dashboard")
cee_dashboard_module_id = modules_by_name.get("CEE Dashboard")
```

### 2. Create Dashboard Module Entries
Add to `modules_data` in seed.py:
```python
{"name": "AEE Dashboard", "path": "aee_dashboard", "group_name": "Testing"},
{"name": "SEE Dashboard", "path": "see_dashboard", "group_name": "Testing"},
{"name": "CEE Dashboard", "path": "cee_dashboard", "group_name": "Testing"},
```

### 3. Build Dashboard Components in Flutter
Create separate dashboard widgets:
- `lib/pages/zoho/ee_tlss_dashboard.dart` - Rich monitoring dashboard
- `lib/pages/zoho/aee_dashboard.dart` - Field-level dashboard
- `lib/pages/zoho/see_dashboard.dart` - Circle-level dashboard
- `lib/pages/zoho/cee_dashboard.dart` - Zone-level dashboard

### 4. Implement Dashboard Router
In `dashboard.dart`:
```dart
Widget build(BuildContext context) {
  final user = await SessionManager().getUser();
  
  // Route to custom dashboard if assigned
  switch (user?.defaultModulePath) {
    case 'ee_tlss_dashboard':
      return EETLSSDashboard(onNavigate: widget.onNavigate);
    case 'aee_dashboard':
      return AEEDashboard(onNavigate: widget.onNavigate);
    case 'see_dashboard':
      return SEEDashboard(onNavigate: widget.onNavigate);
    case 'cee_dashboard':
      return CEEDashboard(onNavigate: widget.onNavigate);
    default:
      // Fall back to dashboard_type logic
      if (_isAdmin) return _buildAdminDashboard(...);
      ...
  }
}
```

## Benefits

✅ **Scalable**: Add new role-specific dashboards without changing core code
✅ **Flexible**: Each role can have completely different dashboard layouts
✅ **Database-driven**: Change role's dashboard by updating one field
✅ **Maintainable**: No hard-coded role checks in UI code
✅ **Gradual migration**: Existing roles use generic dashboards until custom ones are built

## Testing

### Test EE TLSS Login
```bash
curl -X POST http://localhost:8080/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"ee.tlss@kptcl.com","password":"admin123"}' | jq '.user.default_module_path'
```

**Expected:** `"ee_tlss_dashboard"`

### Test Other Roles
```bash
curl -X POST http://localhost:8080/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"aee.maintenance@kptcl.com","password":"admin123"}' | jq '.user.default_module_path'
```

**Expected:** `null` (uses generic supervisor dashboard)

## Files Modified

### Backend
- `models.py` - Added `default_module_id` columns
- `schemas.py` - Added `default_module_path` field
- `routers/auth.py` - Updated login query
- `seed.py` - Added module assignment logic
- `add_default_module_column.py` - Migration script
- `drop_and_reseed.py` - Database reset script

### Frontend
- `lib/models/models.dart` - Added `defaultModulePath` field
- `lib/pages/zoho/dashboard.dart` - Added TODO for routing logic

---

**Date**: 2026-04-19
**Status**: Backend complete, Frontend needs dashboard component implementation
**Next**: Build EE TLSS Dashboard UI component
