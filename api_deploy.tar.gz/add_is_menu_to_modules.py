"""
Migration: Add is_menu column to public.modules table.
Run once: python add_is_menu_to_modules.py
"""
import os, sys
os.chdir(r'C:\Yesu\CustomerAPI\Customer-API')
sys.path.insert(0, r'C:\Yesu\CustomerAPI\Customer-API')

from database import SessionLocal
from sqlalchemy import text

db = SessionLocal()
try:
    # Check if column already exists
    result = db.execute(text("""
        SELECT column_name FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'modules'
          AND column_name = 'is_menu'
    """)).fetchone()

    if result:
        print("Column 'is_menu' already exists — skipping.")
    else:
        db.execute(text("""
            ALTER TABLE public.modules
            ADD COLUMN is_menu BOOLEAN NOT NULL DEFAULT TRUE
        """))
        db.commit()
        print("Column 'is_menu' added to public.modules successfully.")
        print("All existing modules default to is_menu=TRUE (visible in sidebar).")
except Exception as e:
    db.rollback()
    print(f"Error: {e}")
    raise
finally:
    db.close()
