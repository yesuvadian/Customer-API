#!/usr/bin/env python3
"""
Add unique constraint to CategoryDetails table to prevent duplicate (name, category_master_id) combinations.

This migration ensures that no two CategoryDetails rows can have the same name under the same CategoryMaster.
Run this AFTER fixing any existing duplicates with fix_duplicate_category_details.py.
"""
from database import get_db
from sqlalchemy import text

db = next(get_db())

print("=" * 80)
print("ADD UNIQUE CONSTRAINT TO CATEGORYDETAILS")
print("=" * 80)

# Check if constraint already exists
constraint_check = db.execute(text("""
    SELECT constraint_name
    FROM information_schema.table_constraints
    WHERE table_schema = 'public'
      AND table_name = 'CategoryDetails'
      AND constraint_name = 'uq_category_details_name_master'
""")).first()

if constraint_check:
    print("\n[INFO] Unique constraint 'uq_category_details_name_master' already exists.")
    print("[INFO] Nothing to do.")
    db.close()
    exit(0)

# Check for existing duplicates before adding constraint
duplicates = db.execute(text("""
    SELECT name, category_master_id, COUNT(*) as cnt
    FROM "CategoryDetails"
    GROUP BY name, category_master_id
    HAVING COUNT(*) > 1
""")).fetchall()

if duplicates:
    print("\n[ERROR] Found duplicate (name, category_master_id) combinations:")
    for dup in duplicates:
        print(f"  - name: {dup.name}, category_master_id: {dup.category_master_id}, count: {dup.cnt}")
    print("\n[ERROR] Please run fix_duplicate_category_details.py first to clean up duplicates.")
    print("[ERROR] Cannot add unique constraint with existing duplicates.")
    db.close()
    exit(1)

print("\n[INFO] No duplicates found. Adding unique constraint...")

# Add the unique constraint
db.execute(text("""
    ALTER TABLE "CategoryDetails"
    ADD CONSTRAINT uq_category_details_name_master
    UNIQUE (name, category_master_id)
"""))

db.commit()
print("\n[DONE] Successfully added unique constraint 'uq_category_details_name_master'")
print("[INFO] Future attempts to insert duplicate (name, category_master_id) will fail at database level")

db.close()
