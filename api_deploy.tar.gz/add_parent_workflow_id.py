"""
Add parent_workflow_id column to repair_workflows table.

This column links surveillance workflows back to their parent repair/overhaul workflows.
"""

from sqlalchemy import create_engine, text
from database import VENDOR_DATABASE_URL

def add_parent_workflow_id_column():
    engine = create_engine(VENDOR_DATABASE_URL)

    with engine.connect() as conn:
        # Check if column already exists
        check_sql = text("""
            SELECT column_name
            FROM information_schema.columns
            WHERE table_name = 'repair_workflows'
            AND column_name = 'parent_workflow_id'
        """)
        result = conn.execute(check_sql).fetchone()

        if result:
            print("[OK] Column 'parent_workflow_id' already exists.")
            return

        # Add the column
        print("Adding 'parent_workflow_id' column to repair_workflows...")
        add_column_sql = text("""
            ALTER TABLE repair_workflows
            ADD COLUMN parent_workflow_id UUID,
            ADD CONSTRAINT fk_repair_workflows_parent_workflow_id
                FOREIGN KEY (parent_workflow_id)
                REFERENCES repair_workflows(id)
                ON DELETE SET NULL
        """)
        conn.execute(add_column_sql)
        conn.commit()

        # Add index for performance
        print("Adding index on parent_workflow_id...")
        add_index_sql = text("""
            CREATE INDEX IF NOT EXISTS ix_repair_workflows_parent_workflow_id
            ON repair_workflows(parent_workflow_id)
        """)
        conn.execute(add_index_sql)
        conn.commit()

        print("[OK] Successfully added parent_workflow_id column and index.")

if __name__ == "__main__":
    add_parent_workflow_id_column()
