"""
add_source_failure_id.py
────────────────────────
Migration: adds the source_failure_id traceability column to testing_requests.

  testing_requests:
    - source_failure_id  (UUID nullable, FK → testing_requests.id ON DELETE SET NULL)

This column links an auto-created repair_lifecycle TR back to the
Failure Registry (FR-) record that triggered it.

Run:  python add_source_failure_id.py
"""

from database import engine, SessionLocal
from sqlalchemy import text


def run():
    db = SessionLocal()
    try:
        print("[INFO] Adding source_failure_id to testing_requests …")
        db.execute(text("""
            ALTER TABLE public.testing_requests
                ADD COLUMN IF NOT EXISTS source_failure_id UUID
                    REFERENCES public.testing_requests(id) ON DELETE SET NULL;
        """))
        db.commit()
        print("[OK]  source_failure_id column added (or already existed)")

        print("\n" + "=" * 60)
        print("  Migration complete.")
        print("=" * 60)

    except Exception as exc:
        db.rollback()
        print(f"[ERROR] Migration failed: {exc}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    run()
