import os, sys
os.chdir(r'C:\Yesu\CustomerAPI\Customer-API')
sys.path.insert(0, r'C:\Yesu\CustomerAPI\Customer-API')

from database import SessionLocal
from models import OrgRole, OrgRolePermission, Module

db = SessionLocal()

see_rt_role = db.query(OrgRole).filter(OrgRole.name == 'SEE RT').first()
print(f'SEE RT OrgRole id: {see_rt_role.id}')

# Find Testing Requests module (not approvals)
tr_modules = db.query(Module).filter(Module.name.ilike('%testing request%')).all()
for m in tr_modules:
    print(f'  Module found: {m.name} -> {m.id}')

# Ensure Testing Requests has can_view only (no other flags)
for m in tr_modules:
    if 'approval' not in m.name.lower():
        perm = db.query(OrgRolePermission).filter(
            OrgRolePermission.org_role_id == see_rt_role.id,
            OrgRolePermission.module_id == m.id
        ).first()
        if perm:
            # Row exists — strip everything except can_view
            perm.can_add = False
            perm.can_edit = False
            perm.can_delete = False
            perm.can_approve = False
            perm.can_assign = False
            perm.can_export = False
            perm.can_import = False
            print(f'  Updated [{m.name}]: can_view only')
        else:
            # No row — insert with can_view only
            new_perm = OrgRolePermission(
                org_role_id=see_rt_role.id,
                module_id=m.id,
                can_view=True,
                can_add=False,
                can_edit=False,
                can_delete=False,
                can_approve=False,
                can_assign=False,
                can_export=False,
                can_import=False,
            )
            db.add(new_perm)
            print(f'  Inserted [{m.name}]: can_view only')

db.commit()

# Verify final state
print('\nFinal SEE RT permissions:')
perms = (
    db.query(OrgRolePermission, Module)
    .join(Module, Module.id == OrgRolePermission.module_id)
    .filter(OrgRolePermission.org_role_id == see_rt_role.id)
    .all()
)
for p, m in perms:
    flags = [f for f in ['can_view','can_add','can_edit','can_delete','can_approve','can_assign','can_export','can_import'] if getattr(p, f)]
    print(f'  {m.name:40s}: {flags}')

db.close()
print('\nDone.')
