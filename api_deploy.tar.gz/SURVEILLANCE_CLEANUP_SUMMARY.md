# Surveillance Workflow - Code Cleanup Summary

## Overview

Refactored surveillance test scheduling to use existing `test_request_schedules` infrastructure instead of a separate scheduler. This cleanup ensures no duplicate/unused code remains.

---

## Files Deleted ❌

### 1. `services/surveillance_test_scheduler.py`
**Reason:** Replaced by existing `TestRequestScheduleService`

**What it did:**
- `run_daily_scheduler()` - Created testing requests for surveillance workflows
- `update_test_result()` - Updated RepairSurveillanceTest when tests completed

**Replaced by:**
- ✅ `TestRequestScheduleService.run_daily_scheduler()` - Creates testing requests from schedules
- ✅ `SurveillanceTrackingService.update_test_result()` - Updates surveillance tracking

---

## Files Created ✅

### 1. `services/surveillance_tracking_service.py`
**Purpose:** Track surveillance test completion and results

**Key Functions:**
- `update_test_result()` - Updates RepairSurveillanceTest when test completes
- `_send_abnormal_alert()` - Sends notification when test fails (optional)

**Called from:** `TestingService.submit_test_results()`

### 2. `migrations/013_add_surveillance_to_schedules.sql`
**Purpose:** Add surveillance linkage to test_request_schedules table

**Changes:**
- Adds `surveillance_workflow_id` column
- Adds `surveillance_quarter` column
- Creates index for efficient querying

### 3. `run_migration_013.py`
**Purpose:** Migration runner for 013

---

## Files Updated 🔧

### 1. `models.py`
**Lines 2689-2706**

Added to `TestRequestSchedule` model:
```python
# SURVEILLANCE WORKFLOW LINKAGE
surveillance_workflow_id = Column(
    UUID(as_uuid=True),
    ForeignKey("public.repair_workflows.id", ondelete="CASCADE"),
    nullable=True,
    index=True,
)

surveillance_quarter = Column(
    Integer,
    nullable=True,
)
```

### 2. `surveillance_hooks.py`
**Lines 160-270**

Added `_create_surveillance_test_schedules()` function:
- Creates `TestRequestSchedule` records (not testing_requests directly)
- Sets `surveillance_workflow_id` and `surveillance_quarter` on schedules
- Creates 16 schedules total (4 quarters × 4 test types)

### 3. `services/test_request_schedule_service.py`
**Lines 473-482**

Modified `create_one_ticket()` to copy surveillance fields:
```python
new_data = {
    ...
    "surveillance_workflow_id": schedule.surveillance_workflow_id,
    "surveillance_quarter": schedule.surveillance_quarter,
}
```

### 4. `services/testing_service.py`
**Lines 1-10, 167-183**

Added logger import and surveillance tracking call in `submit_test_results()`:
```python
# After test submission
if request.surveillance_workflow_id:
    SurveillanceTrackingService(self.db).update_test_result(
        testing_request_id=request_id,
        test_status='completed',
        result_status=latest_result.overall_result,
        tested_at=latest_result.tested_at
    )
```

### 5. `SURVEILLANCE_VALIDATION.md`
**Lines 169-176**

Updated "Related Files" section to reference new files instead of deleted scheduler.

---

## Verification Checklist ✓

### Code References
- [x] No imports of `surveillance_test_scheduler` remaining
- [x] No calls to old `run_daily_scheduler()` from deleted file
- [x] All `update_test_result()` calls now use `SurveillanceTrackingService`

### Functionality Preserved
- [x] Testing requests still created for surveillance workflows
- [x] RepairSurveillanceTest still updated when tests complete
- [x] Abnormal flag still set based on result_status
- [x] Alerts sent when tests fail (via SurveillanceTrackingService)

### Database Schema
- [x] `test_request_schedules.surveillance_workflow_id` column exists
- [x] `test_request_schedules.surveillance_quarter` column exists
- [x] `testing_requests.surveillance_workflow_id` column exists (from migration 008)
- [x] `testing_requests.surveillance_quarter` column exists (from migration 008)
- [x] `repair_surveillance_tests` table exists (from migration 008)

### Integration Points
- [x] `surveillance_hooks.py` creates schedules when workflow starts
- [x] `TestRequestScheduleService.run_daily_scheduler()` creates testing requests from schedules
- [x] `TestingService.submit_test_results()` updates surveillance tracking
- [x] `RepairWorkflowService.submit_stage()` validates test completion

---

## Migration Required

**Before deploying this cleanup:**

```bash
# Run migration 013 to add surveillance fields to schedules
python run_migration_013.py
```

**Migration adds:**
- `test_request_schedules.surveillance_workflow_id` (UUID)
- `test_request_schedules.surveillance_quarter` (INTEGER)
- Index: `idx_test_request_schedules_surveillance`

---

## Testing Checklist

### 1. Surveillance Workflow Creation
```
✓ Create repair workflow
✓ Complete final stage
✓ Verify surveillance workflow created
✓ Verify 16 TestRequestSchedule records created
✓ Verify schedules have surveillance_workflow_id and surveillance_quarter set
```

### 2. Test Request Creation
```
✓ Wait for daily scheduler to run (or trigger manually)
✓ Verify 4 testing requests created for current quarter
✓ Verify testing_requests have surveillance_workflow_id and surveillance_quarter
✓ Verify source_schedule_id links back to schedule
```

### 3. Test Completion
```
✓ Submit test result with status='PASS'
✓ Verify RepairSurveillanceTest updated (test_status='completed', is_abnormal=false)
✓ Submit test result with status='FAIL'
✓ Verify RepairSurveillanceTest updated (is_abnormal=true)
✓ Verify notification sent for failed test
```

### 4. Stage Submission
```
✓ Try to submit Q1 stage with incomplete tests → should fail
✓ Complete all 4 tests
✓ Submit Q1 stage → should succeed
✓ Verify quarterly review form shows correct test results
```

### 5. Final Evaluation
```
✓ Complete all 4 quarters
✓ Open final evaluation form
✓ Verify 24-month summary shows correct stats
✓ Verify quality rating calculated correctly
```

---

## Files That Reference Surveillance (Updated)

### Core Services
- ✅ `services/surveillance_config_service.py` - Configuration resolution
- ✅ `services/surveillance_template_service.py` - Form pre-population
- ✅ `services/surveillance_tracking_service.py` - **NEW** - Test result tracking
- ✅ `services/test_request_schedule_service.py` - Creates testing requests from schedules
- ✅ `services/repair_workflow_service.py` - Stage validation

### Workflow & Hooks
- ✅ `surveillance_hooks.py` - Creates schedules when workflow starts
- ✅ `workflow_hooks.py` - Hook registry (no changes needed)

### Models & Database
- ✅ `models.py` - All surveillance models and linkage fields
- ✅ `migrations/008_surveillance_workflow.sql` - Main surveillance schema
- ✅ `migrations/013_add_surveillance_to_schedules.sql` - **NEW** - Schedule linkage

### API Routers
- ✅ `routers/repair_workflow.py` - Surveillance endpoints (no changes needed)

### Documentation
- ✅ `SURVEILLANCE_WORKFLOW_FLOW.md` - Overall flow
- ✅ `SURVEILLANCE_VALIDATION.md` - Stage validation
- ✅ `SURVEILLANCE_SCHEDULER_INTEGRATION.md` - **NEW** - Scheduler integration details
- ✅ `SURVEILLANCE_CLEANUP_SUMMARY.md` - **NEW** - This file

---

## Summary

**Before:**
```
surveillance_test_scheduler.py (separate daily cron)
  ↓
Creates testing_requests directly
  ↓
Updates RepairSurveillanceTest on completion
```

**After:**
```
surveillance_hooks.py
  ↓
Creates TestRequestSchedule records (with surveillance linkage)
  ↓
TestRequestScheduleService.run_daily_scheduler() (existing cron)
  ↓
Creates testing_requests from schedules
  ↓
TestingService.submit_test_results()
  ↓
SurveillanceTrackingService.update_test_result()
  ↓
Updates RepairSurveillanceTest + sends alerts
```

**Benefits:**
- ✅ No duplicate schedulers
- ✅ Reuses existing infrastructure
- ✅ Follows same pattern as calibration, TAQC, etc.
- ✅ Explicit database linkage (surveillance_workflow_id on both schedules and requests)
- ✅ Cleaner codebase with clear separation of concerns

**Changes:**
- 1 file deleted (`surveillance_test_scheduler.py`)
- 2 files created (`surveillance_tracking_service.py`, migration 013)
- 5 files updated (`models.py`, `surveillance_hooks.py`, `test_request_schedule_service.py`, `testing_service.py`, docs)
- 1 migration added (013)

---

## Deployment Steps

1. **Deploy code changes**
   ```bash
   git pull
   ```

2. **Run migration 013**
   ```bash
   python run_migration_013.py
   ```

3. **Restart application** (to pick up new code)
   ```bash
   systemctl restart customer-api  # or your restart command
   ```

4. **Verify**
   - Check logs for any import errors
   - Create a test surveillance workflow
   - Verify schedules created
   - Verify daily scheduler processes them correctly

---

## Rollback Plan

If issues arise:

1. **Revert code changes**
   ```bash
   git revert <commit-hash>
   ```

2. **Rollback migration 013** (if needed)
   ```sql
   ALTER TABLE test_request_schedules DROP COLUMN IF EXISTS surveillance_workflow_id;
   ALTER TABLE test_request_schedules DROP COLUMN IF EXISTS surveillance_quarter;
   DROP INDEX IF EXISTS idx_test_request_schedules_surveillance;
   ```

3. **Restore old scheduler file** (from git history)
   ```bash
   git checkout <old-commit> -- services/surveillance_test_scheduler.py
   ```

4. **Restart application**
