#!/usr/bin/env python3
"""
Fix duplicate CategoryDetails rows and consolidate OrgTestTemplate references.

Finds duplicate test type names in CategoryDetails, keeps the lowest ID,
updates all foreign keys, and deletes duplicates.
"""
from database import get_db
from sqlalchemy import text
from collections import defaultdict

db = next(get_db())

print("=" * 80)
print("CATEGORY DETAILS DUPLICATE CLEANUP")
print("=" * 80)

# Find all CategoryDetails with duplicate names
result = db.execute(text("""
    SELECT id, name, category_master_id, category_type
    FROM "CategoryDetails"
    ORDER BY name, id
""")).fetchall()

# Group by name to find duplicates
by_name = defaultdict(list)
for r in result:
    by_name[r.name].append(r)

duplicates = {name: rows for name, rows in by_name.items() if len(rows) > 1}

if not duplicates:
    print("\n[OK] No duplicate CategoryDetails found.")
    db.close()
    exit(0)

print(f"\nFound {len(duplicates)} test types with duplicates:\n")

consolidation_plan = []
for name, rows in sorted(duplicates.items()):
    keep_id = min(r.id for r in rows)
    delete_ids = [r.id for r in rows if r.id != keep_id]

    print(f"{name}:")
    print(f"  KEEP: ID {keep_id}")
    for did in delete_ids:
        print(f"  DELETE: ID {did}")

    consolidation_plan.append({
        'name': name,
        'keep_id': keep_id,
        'delete_ids': delete_ids
    })
    print()

print("=" * 80)
print(f"Will consolidate {len(consolidation_plan)} test types")
print("=" * 80)

# Execute consolidation
for plan in consolidation_plan:
    name = plan['name']
    keep_id = plan['keep_id']
    delete_ids = plan['delete_ids']

    print(f"\n[CONSOLIDATE] {name}")
    print(f"  Keeping ID: {keep_id}")

    for del_id in delete_ids:
        # Update OrgTestTemplate references
        updated = db.execute(
            text("UPDATE org_test_templates SET test_type_id = :keep WHERE test_type_id = :del"),
            {"keep": keep_id, "del": del_id}
        ).rowcount
        print(f"  Updated {updated} OrgTestTemplate records from ID {del_id} -> {keep_id}")

        # Check for other tables with foreign keys to CategoryDetails
        # Add more updates here if needed for other tables

        # Delete duplicate CategoryDetails row
        db.execute(
            text('DELETE FROM "CategoryDetails" WHERE id = :id'),
            {"id": del_id}
        )
        print(f"  Deleted CategoryDetails ID {del_id}")

db.commit()
print(f"\n[DONE] Successfully consolidated {len(consolidation_plan)} duplicate test types")

# Now clean up duplicate OrgTestTemplate rows (same template_key + test_type_id)
print("\n" + "=" * 80)
print("CLEANING UP DUPLICATE ORG_TEST_TEMPLATES")
print("=" * 80)

duplicate_templates = db.execute(text("""
    SELECT template_key, test_type_id, COUNT(*) as cnt, ARRAY_AGG(id) as ids
    FROM org_test_templates
    WHERE test_type_id IS NOT NULL
    GROUP BY template_key, test_type_id
    HAVING COUNT(*) > 1
""")).fetchall()

if duplicate_templates:
    print(f"\nFound {len(duplicate_templates)} duplicate template combos:")

    for dt in duplicate_templates:
        ids = dt.ids
        keep_id = ids[0]
        delete_ids = ids[1:]

        print(f"\nKey: {dt.template_key}, TestTypeID: {dt.test_type_id}")
        print(f"  KEEP: {keep_id}")

        for del_id in delete_ids:
            db.execute(text("DELETE FROM org_test_templates WHERE id = :id"), {"id": del_id})
            print(f"  DELETED: {del_id}")

    db.commit()
    print(f"\n[DONE] Cleaned up {len(duplicate_templates)} duplicate templates")
else:
    print("\n[OK] No duplicate OrgTestTemplate records found")

db.close()
