"""
Grant all module permissions to Admin role in KPTCL organization
"""
from database import get_db
from models import Organization, OrgRole, Module, OrgRolePermission
import uuid

def fix_admin_permissions():
    db = next(get_db())
    
    # Find KPTCL organization
    kptcl = db.query(Organization).filter(Organization.code == 'KPTCL').first()
    if not kptcl:
        print("[ERROR] KPTCL organization not found")
        return
    
    print(f"[OK] Found organization: {kptcl.name} (ID: {kptcl.id})")
    
    # Find Admin role in KPTCL
    admin_role = db.query(OrgRole).filter(
        OrgRole.organization_id == kptcl.id,
        OrgRole.name == 'Admin'
    ).first()
    
    if not admin_role:
        print("[ERROR] Admin role not found in KPTCL")
        return
    
    print(f"[OK] Found role: {admin_role.name} (ID: {admin_role.id})")
    
    # Get all active modules
    modules = db.query(Module).filter(Module.isactive == True).all()
    print(f"[OK] Found {len(modules)} active modules")
    
    added = 0
    updated = 0
    
    for module in modules:
        existing = db.query(OrgRolePermission).filter(
            OrgRolePermission.org_role_id == admin_role.id,
            OrgRolePermission.module_id == module.id
        ).first()
        
        if existing:
            # Update to grant all permissions
            changed = False
            if not existing.can_view:
                existing.can_view = True
                changed = True
            if not existing.can_add:
                existing.can_add = True
                changed = True
            if not existing.can_edit:
                existing.can_edit = True
                changed = True
            if not existing.can_delete:
                existing.can_delete = True
                changed = True
            if not existing.can_approve:
                existing.can_approve = True
                changed = True
            
            if changed:
                updated += 1
                print(f"  [UPDATE] {module.name}")
        else:
            # Create new permission with full access
            perm = OrgRolePermission(
                id=uuid.uuid4(),
                org_role_id=admin_role.id,
                module_id=module.id,
                can_view=True,
                can_add=True,
                can_edit=True,
                can_delete=True,
                can_approve=True
            )
            db.add(perm)
            added += 1
            print(f"  [ADD] {module.name}")
    
    db.commit()
    print(f"\n[SUCCESS] Admin role permissions updated:")
    print(f"  - {added} modules added")
    print(f"  - {updated} modules updated")
    print(f"  - Total: {len(modules)} modules with full permissions")
    print(f"\nPlease logout and login again as orgadmin@utility.com to see all modules.")
    
    db.close()

if __name__ == "__main__":
    fix_admin_permissions()
