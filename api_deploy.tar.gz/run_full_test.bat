@echo off
setlocal enabledelayedexpansion

REM Full Test Suite Runner (Windows)
REM This script runs the complete multi-session testing workflow

echo ========================================
echo   Multi-Session Testing - Full Suite
echo ========================================
echo.

REM Database configuration (from .env)
set DB_NAME=Relu_Vendor2
set DB_USER=relu_user
set DB_HOST=localhost
set DB_PORT=5432
set PGPASSWORD=StrongPassword123!

echo Step 1: Checking PostgreSQL connection...
psql -U %DB_USER% -d %DB_NAME% -h %DB_HOST% -p %DB_PORT% -c "SELECT version();" > nul 2>&1

if %errorlevel% neq 0 (
    echo ERROR: Cannot connect to PostgreSQL database
    echo Please ensure:
    echo   1. PostgreSQL is running
    echo   2. Database '%DB_NAME%' exists
    echo   3. User '%DB_USER%' has access
    pause
    exit /b 1
)

echo PostgreSQL connection successful
echo.

REM Ask for confirmation
echo WARNING: This will DROP ALL TABLES in database '%DB_NAME%'
set /p confirmation="Do you want to continue? (yes/no): "

if /i not "%confirmation%"=="yes" (
    echo Aborted
    exit /b 1
)

echo.
echo Step 2: Dropping all tables...

REM Drop all tables via Python
python -c "from database import engine; from sqlalchemy import text; engine.execute(text('DROP SCHEMA IF EXISTS public CASCADE')); engine.execute(text('CREATE SCHEMA public')); engine.execute(text('GRANT ALL ON SCHEMA public TO relu_user')); print('Tables dropped')"

if %errorlevel% neq 0 (
    echo Failed to drop tables
    exit /b 1
)

echo.
echo Step 3: Running migrations...

REM Run migration 003
echo   - Running migration 003_add_multi_session_testing.sql
psql -U %DB_USER% -d %DB_NAME% -h %DB_HOST% -p %DB_PORT% -f migrations\003_add_multi_session_testing.sql > nul

if %errorlevel% neq 0 (
    echo Migration 003 failed
    exit /b 1
)

REM Run migration 004
echo   - Running migration 004_add_session_comments.sql
psql -U %DB_USER% -d %DB_NAME% -h %DB_HOST% -p %DB_PORT% -f migrations\004_add_session_comments.sql > nul

if %errorlevel% neq 0 (
    echo Migration 004 failed
    exit /b 1
)

echo   Migrations completed
echo.

echo Step 4: Creating tables...

REM Create tables via SQLAlchemy
python -c "from database import Base, engine; from models import *; Base.metadata.create_all(bind=engine); print('Tables created')"

if %errorlevel% neq 0 (
    echo Failed to create tables
    exit /b 1
)

echo.
echo Step 5: Running seed script...

python seed.py

if %errorlevel% neq 0 (
    echo Failed to load seed data
    exit /b 1
)

echo.
echo ========================================
echo   Database Setup Complete!
echo ========================================
echo.

echo Step 6: Starting backend server...
echo.
echo IMPORTANT: The backend server will start in a new window.
echo           Close this window when you see "Application startup complete"
echo.
pause

REM Start backend in new window
start "FastAPI Backend" cmd /k "uvicorn main:app --reload --port 8000"

echo Waiting for backend to start (10 seconds)...
timeout /t 10 /nobreak > nul

echo.
echo Step 7: Running test script...
echo.

python test_multi_session_complete.py

echo.
echo ========================================
echo   Testing Complete!
echo ========================================
echo.
echo The backend server is still running in another window.
echo Close that window to stop the server.
echo.
pause
