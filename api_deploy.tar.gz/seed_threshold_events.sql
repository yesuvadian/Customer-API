-- Seed threshold event types for notification system
INSERT INTO event_catalogue (event_type, label, description, category, severity)
VALUES
    ('test_result_normal', 'Test Result - Normal', 'Test completed successfully with all values in normal range', 'testing', 'info'),
    ('test_result_alert', 'Test Result - Alert', 'Test completed with one or more values in alert/warning range', 'testing', 'alert'),
    ('test_result_critical', 'Test Result - Critical', 'Test completed with one or more values in critical/failure range', 'testing', 'critical')
ON CONFLICT (event_type) DO NOTHING;

-- Verify insertion
SELECT event_type, label, severity FROM event_catalogue
WHERE event_type IN ('test_result_normal', 'test_result_alert', 'test_result_critical')
ORDER BY severity DESC;
