"""
add_test_register_columns.py
────────────────────────────
Migration: adds Test Register support columns.

  testing_requests:
    - is_schedule_template  (BOOLEAN DEFAULT FALSE)
    - source_schedule_id    (UUID nullable FK → test_request_schedules.id)

  test_request_schedules:
    - revised_periodicity_days  (INTEGER nullable)
    - oem_reference             (TEXT nullable)

Also extends the ScheduleFrequency enum with:
    semi_annual, triennial

Run:  python add_test_register_columns.py
"""

from database import engine, SessionLocal
from sqlalchemy import text


def run():
    # ── 1. Extend ScheduleFrequency enum ──────────────────────────────────────
    # ALTER TYPE requires AUTOCOMMIT — cannot run inside a transaction block.
    print("[INFO] Extending ScheduleFrequency enum …")
    with engine.connect() as conn:
        conn.execution_options(isolation_level="AUTOCOMMIT")
        for val in ("semi_annual", "triennial"):
            conn.execute(text(
                f"ALTER TYPE public.\"ScheduleFrequency\" ADD VALUE IF NOT EXISTS '{val}';"
            ))
    print("[OK]  Enum values added (or already existed)")

    db = SessionLocal()
    try:

        # ── 2. testing_requests ───────────────────────────────────────────────
        print("[INFO] Patching testing_requests …")
        db.execute(text("""
            ALTER TABLE public.testing_requests
                ADD COLUMN IF NOT EXISTS is_schedule_template
                    BOOLEAN NOT NULL DEFAULT FALSE;
        """))
        db.execute(text("""
            ALTER TABLE public.testing_requests
                ADD COLUMN IF NOT EXISTS source_schedule_id
                    UUID REFERENCES public.test_request_schedules(id)
                    ON DELETE SET NULL;
        """))
        db.commit()
        print("[OK]  testing_requests patched")

        # ── 3. test_request_schedules ─────────────────────────────────────────
        print("[INFO] Adding Test Register columns to test_request_schedules …")
        db.execute(text("""
            ALTER TABLE public.test_request_schedules
                ADD COLUMN IF NOT EXISTS revised_periodicity_days INTEGER,
                ADD COLUMN IF NOT EXISTS oem_reference TEXT;
        """))
        db.commit()
        print("[OK]  test_request_schedules patched")

        # ── 4. Re-activate schedules deactivated by missing column bug ──────────
        print("[INFO] Re-activating schedules auto-deactivated by consecutive failures …")
        db.execute(text("""
            UPDATE public.test_request_schedules
               SET is_active = TRUE,
                   consecutive_failures = 0,
                   paused_at = NULL,
                   paused_by = NULL,
                   pause_reason = NULL
             WHERE equipment_id IS NOT NULL
               AND is_deleted = FALSE
               AND is_active = FALSE
               AND paused_at IS NULL;
        """))
        db.commit()
        print("[OK]  Schedules re-activated")

        print("\n" + "=" * 60)
        print("  Test Register migration complete.")
        print("=" * 60)

    except Exception as exc:
        db.rollback()
        print(f"[ERROR] Migration failed: {exc}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    run()
