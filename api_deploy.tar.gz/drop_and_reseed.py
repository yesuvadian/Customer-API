"""
Drop all tables, recreate schema, and run seed
"""
from sqlalchemy import text
from database import engine, get_db
from models import Base
import seed

def main():
    print("WARNING: This will drop ALL tables!")

    # Use raw SQL with CASCADE to handle circular dependencies
    print("Dropping schema public CASCADE...")
    with engine.connect() as conn:
        conn.execute(text("DROP SCHEMA IF EXISTS public CASCADE"))
        conn.execute(text("CREATE SCHEMA public"))
        conn.commit()
    print("Schema dropped and recreated.")

    # Recreate all tables
    print("Creating all tables from models...")
    Base.metadata.create_all(bind=engine)
    print("All tables created.")

    # Run seed
    print("\nRunning seed...")
    seed.run_seed()
    print("\nDatabase seeded successfully!")

if __name__ == "__main__":
    main()
