# Multi-Session Testing - Deployment Checklist

**Date**: 2026-04-21  
**Status**: Ready for deployment  
**Components**: Backend API + Flutter UI

---

## 📋 Pre-Deployment Checklist

### Backend

- [ ] **Review Code Changes**
  - [ ] `models.py` - test_session_id column added
  - [ ] `schemas.py` - test_session_id in request/response
  - [ ] `services/testing_service.py` - session link logic
  - [ ] `routers/testing.py` - endpoint accepts session_id
  - [ ] Migration script reviewed

- [ ] **Database Migration Ready**
  - [ ] Migration file: `migrations/add_test_session_id_to_results.sql`
  - [ ] Backup plan prepared
  - [ ] Rollback script available

- [ ] **Testing**
  - [ ] Unit tests pass
  - [ ] Integration tests pass
  - [ ] API endpoint manually tested
  - [ ] Backward compatibility verified

### Flutter

- [ ] **Review Code Changes**
  - [ ] `test_template_provider.dart` - testSessionId parameter
  - [ ] `test_result_form.dart` - accepts testSessionId
  - [ ] `testing_detail.dart` - passes session ID
  - [ ] `test_session_page.dart` - edit/delete UI
  - [ ] `test_session_provider.dart` - statistics call
  - [ ] `session_timeline_view.dart` - displays stats

- [ ] **Testing**
  - [ ] App builds successfully
  - [ ] No Dart compilation errors
  - [ ] Multi-session workflow tested
  - [ ] Single-session workflow tested
  - [ ] Edit reading tested
  - [ ] Statistics display verified

---

## 🚀 Deployment Steps

### Phase 1: Backend Deployment

#### Step 1: Database Backup
```bash
# Production backup
pg_dump -h prod-db-host -U postgres -d customer_db > backup_$(date +%Y%m%d_%H%M%S).sql

# Verify backup
ls -lh backup_*.sql
```

#### Step 2: Apply Migration
```bash
# Connect to production database
psql -h prod-db-host -U postgres -d customer_db

# Apply migration
\i migrations/add_test_session_id_to_results.sql

# Verify column added
\d test_results

# Expected output:
# test_session_id | uuid | | |

# Verify foreign key
\d+ test_results

# Expected output:
# Foreign-key constraints:
#   "fk_test_results_session" FOREIGN KEY (test_session_id) ...
```

#### Step 3: Deploy Backend Code
```bash
# Pull latest code
cd /path/to/Customer-API
git checkout feature/seacms-ai-equipment-register
git pull origin feature/seacms-ai-equipment-register

# Restart API server
systemctl restart customer-api
# OR
supervisorctl restart customer-api
# OR
pm2 restart customer-api

# Check logs
tail -f /var/log/customer-api/app.log
```

#### Step 4: Verify Backend
```bash
# Health check
curl http://api-host:8000/health

# Test result submission with session_id
curl -X POST http://api-host:8000/testing/{request-id}/results/structured \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "template_key": "test_template",
    "test_data": {},
    "test_session_id": "session-uuid-here"
  }'

# Verify in database
psql -h prod-db-host -U postgres -d customer_db -c \
  "SELECT id, test_session_id FROM test_results ORDER BY cts DESC LIMIT 5"

# Should see test_session_id populated for new results
```

---

### Phase 2: Flutter Deployment

#### Step 1: Build Flutter App
```bash
cd /path/to/coginiwattcustomer

# Clean build
flutter clean
flutter pub get

# Build for web (if web deployment)
flutter build web --release

# Build for Android (if mobile deployment)
flutter build apk --release
# OR
flutter build appbundle --release

# Build for iOS (if iOS deployment)
flutter build ios --release
```

#### Step 2: Run Tests
```bash
# Check for compilation errors
flutter analyze

# Run tests (if you have tests)
flutter test

# Verify no issues
# Expected: All tests pass, no analysis issues
```

#### Step 3: Deploy Flutter
```bash
# For web deployment:
# Copy build/web/* to web server
rsync -avz build/web/ user@web-host:/var/www/customer-app/

# For mobile deployment:
# Upload to Play Store / App Store
# OR distribute APK to testers

# Verify deployment
curl http://web-host/customer-app/
# Should return HTML
```

---

## 🧪 Post-Deployment Testing

### Test Case 1: Multi-Session Result Tracking

**Scenario**: Create multi-session request and verify per-session results

```bash
# 1. Create testing request with 3 sessions
# 2. Start Session 1
# 3. Submit result for Session 1
# 4. Check database

psql -h prod-db-host -U postgres -d customer_db -c \
  "SELECT tr.id, ts.session_number, tr.overall_result 
   FROM test_results tr 
   JOIN test_sessions ts ON tr.test_session_id = ts.id 
   WHERE tr.testing_request_id = '<request_id>'"

# Expected: 1 row, session_number = 1

# 5. Complete Session 1, Start Session 2
# 6. Submit result for Session 2
# 7. Check database again

psql -h prod-db-host -U postgres -d customer_db -c \
  "SELECT tr.id, ts.session_number, tr.overall_result 
   FROM test_results tr 
   JOIN test_sessions ts ON tr.test_session_id = ts.id 
   WHERE tr.testing_request_id = '<request_id>' 
   ORDER BY ts.session_number"

# Expected: 2 rows
# Row 1: session_number = 1, overall_result = pass
# Row 2: session_number = 2, overall_result = fail
```

**Result**: ✅ Per-session tracking working

---

### Test Case 2: Backward Compatibility

**Scenario**: Single-session request still works

```bash
# 1. Create testing request WITHOUT multi-session
# 2. Submit result (no session_id in request)
# 3. Check database

psql -h prod-db-host -U postgres -d customer_db -c \
  "SELECT id, testing_request_id, test_session_id, overall_result 
   FROM test_results 
   WHERE testing_request_id = '<single_session_request_id>'"

# Expected: 
# test_session_id = NULL (legacy behavior)
# overall_result populated correctly
```

**Result**: ✅ Single-session workflow unaffected

---

### Test Case 3: Edit Reading

**Scenario**: Tester can edit reading after creation

```bash
# 1. Create session and add reading
# 2. In UI, click Edit button on reading
# 3. Modify reading data and status
# 4. Save
# 5. Verify update in database

psql -h prod-db-host -U postgres -d customer_db -c \
  "SELECT reading_data, result_status, mts 
   FROM test_session_readings 
   WHERE id = '<reading_id>'"

# Expected: 
# reading_data updated
# result_status updated
# mts (modified timestamp) updated
```

**Result**: ✅ Edit functionality working

---

### Test Case 4: Statistics Display

**Scenario**: Timeline shows accurate statistics

```bash
# 1. Create session with 5 readings (3 pass, 2 fail)
# 2. Complete session
# 3. Check API response

curl http://api-host:8000/testing_requests/{request_id}/sessions/{session_id}/statistics \
  -H "Authorization: Bearer $TOKEN"

# Expected:
# {
#   "reading_count": 5,
#   "pass_count": 3,
#   "fail_count": 2,
#   "duration_minutes": 45,
#   "status": "completed"
# }

# 4. Check UI timeline
# Expected: Timeline displays "3 pass, 2 fail"
```

**Result**: ✅ Statistics accurate

---

## 🔍 Monitoring

### Key Metrics to Watch

#### Backend
```sql
-- Monitor result creation with sessions
SELECT 
  DATE(cts) as date,
  COUNT(*) as total_results,
  COUNT(CASE WHEN test_session_id IS NOT NULL THEN 1 END) as multi_session_results,
  COUNT(CASE WHEN test_session_id IS NULL THEN 1 END) as single_session_results
FROM test_results
WHERE cts >= NOW() - INTERVAL '7 days'
GROUP BY DATE(cts)
ORDER BY date DESC;

-- Monitor session completion
SELECT 
  status,
  COUNT(*) as count
FROM test_sessions
WHERE cts >= NOW() - INTERVAL '7 days'
GROUP BY status;
```

#### Application Logs
```bash
# Watch for errors
tail -f /var/log/customer-api/app.log | grep -i error

# Watch for session-related activity
tail -f /var/log/customer-api/app.log | grep -i session
```

---

## 🐛 Rollback Plan

### If Issues Detected

#### Backend Rollback
```bash
# 1. Revert code
cd /path/to/Customer-API
git revert <commit_hash>

# 2. Restart API
systemctl restart customer-api

# 3. If database rollback needed (CAREFUL!)
# NOTE: Only if NO new data created yet
psql -h prod-db-host -U postgres -d customer_db

-- Remove FK constraint
ALTER TABLE test_results DROP CONSTRAINT fk_test_results_session;

-- Remove column
ALTER TABLE test_results DROP COLUMN test_session_id;

-- Remove index
DROP INDEX idx_test_results_session_id;
```

#### Flutter Rollback
```bash
# 1. Revert to previous build
cd /path/to/coginiwattcustomer
git revert <commit_hash>

# 2. Rebuild
flutter clean
flutter build web --release

# 3. Redeploy
rsync -avz build/web/ user@web-host:/var/www/customer-app/
```

---

## ✅ Success Criteria

### Backend
- [ ] Migration applied successfully
- [ ] No database errors
- [ ] API responds to health check
- [ ] Results can be created with test_session_id
- [ ] Results can be created without test_session_id (backward compat)
- [ ] No increase in error rate
- [ ] Response times stable

### Flutter
- [ ] App builds successfully
- [ ] No compilation errors
- [ ] Multi-session workflow functional
- [ ] Single-session workflow functional
- [ ] Edit reading works
- [ ] Statistics display correctly
- [ ] No user-reported issues

---

## 📞 Support

### Contacts
- **Backend**: [Backend Team]
- **Flutter**: [Frontend Team]
- **Database**: [DBA Team]
- **DevOps**: [DevOps Team]

### Documentation
- **Backend Changes**: `MULTI_SESSION_GAPS_FIXED.md`
- **Flutter Changes**: `FLUTTER_FIXES_APPLIED.md`
- **Code Review**: `FLUTTER_CODE_REVIEW_FINDINGS.md`
- **Implementation Guide**: `FLUTTER_IMPLEMENTATION_GUIDE.md`
- **Quick Reference**: `QUICK_MULTI_SESSION_GUIDE.md`

---

## 📝 Post-Deployment Tasks

- [ ] Update team on successful deployment
- [ ] Monitor for 24 hours
- [ ] Collect user feedback
- [ ] Document any issues encountered
- [ ] Update runbooks if needed
- [ ] Close related tickets/issues

---

## 🎉 Deployment Complete!

Once all checklist items are complete and testing passes, the multi-session testing system is **production ready**.

**Final Verification**: Run end-to-end test from request creation → multi-session execution → per-session results → statistics display.

✅ **Expected Result**: Complete multi-session workflow functional with per-session tracking!
