"""
Add notification templates for testing request workflow events.
Run: python add_request_notification_templates.py
"""

from database import get_db
from models import NotificationTemplate

def add_templates():
    db = next(get_db())

    templates = [
        {
            "event_type": "request_submitted",
            "channel": "inapp",
            "subject_template": "Testing Request Submitted",
            "body_template": "Testing request {request_number} for {equipment} ({category}) has been submitted by {originator} and is awaiting assignment.",
            "recipient_roles": ["Testing Coordinator", "Admin"],
            "organization_id": None,  # Global template
            "is_active": True,
        },
        {
            "event_type": "tester_assigned",
            "channel": "inapp",
            "subject_template": "Testing Request Assigned",
            "body_template": "Testing request {request_number} for {equipment} has been assigned to {tester}.",
            "recipient_roles": ["Tester", "Testing Coordinator"],
            "organization_id": None,
            "is_active": True,
        },
        {
            "event_type": "request_submitted",
            "channel": "email",
            "subject_template": "New Testing Request: {request_number}",
            "body_template": """
<h2>Testing Request Submitted</h2>
<p>A new testing request has been submitted and requires assignment.</p>
<ul>
  <li><strong>Request Number:</strong> {request_number}</li>
  <li><strong>Equipment:</strong> {equipment}</li>
  <li><strong>Category:</strong> {category}</li>
  <li><strong>Submitted by:</strong> {originator}</li>
</ul>
<p>Please log in to assign a tester.</p>
""",
            "recipient_roles": ["Testing Coordinator", "Admin"],
            "organization_id": None,
            "is_active": True,
        },
        {
            "event_type": "tester_assigned",
            "channel": "email",
            "subject_template": "Testing Assignment: {request_number}",
            "body_template": """
<h2>Testing Request Assigned to You</h2>
<p>You have been assigned to a testing request.</p>
<ul>
  <li><strong>Request Number:</strong> {request_number}</li>
  <li><strong>Equipment:</strong> {equipment}</li>
</ul>
<p>Please log in to accept and begin testing.</p>
""",
            "recipient_roles": ["Tester"],
            "organization_id": None,
            "is_active": True,
        },
    ]

    added = 0
    for t in templates:
        # Check if already exists
        existing = db.query(NotificationTemplate).filter(
            NotificationTemplate.event_type == t["event_type"],
            NotificationTemplate.channel == t["channel"],
            NotificationTemplate.organization_id.is_(None),
        ).first()

        if existing:
            print(f"[SKIP] {t['event_type']} / {t['channel']} already exists")
            continue

        template = NotificationTemplate(**t)
        db.add(template)
        added += 1
        print(f"[ADD] {t['event_type']} / {t['channel']}")

    db.commit()
    print(f"\n✅ Added {added} notification templates")

if __name__ == "__main__":
    add_templates()
