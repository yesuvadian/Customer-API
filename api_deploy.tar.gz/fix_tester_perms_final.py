"""
Final fix for Field Tester and Lab Tester permissions.
Delete all permissions and add only the 4 required modules.
"""
from database import get_db
from models import OrgRole, OrgRolePermission
from datetime import datetime
import uuid

db = next(get_db())

# Get KPTCL Field Tester and Lab Tester roles
roles = db.query(OrgRole).filter(
    OrgRole.organization_id == '29e36785-97db-4bbd-b0b8-b3609a56afb2',
    OrgRole.name.in_(['Field Tester', 'Lab Tester'])
).all()

CORRECT_MODULES = [45, 46, 49, 51]  # Testing Requests, Testing, Testing Request Approvals, Tester Mapping

for role in roles:
    print(f'\nFixing: {role.name}')

    # Delete ALL permissions
    deleted = db.query(OrgRolePermission).filter(
        OrgRolePermission.org_role_id == role.id
    ).delete()
    print(f'  Deleted {deleted} permissions')

    # Add only 4 correct permissions
    now = datetime.now(datetime.now().astimezone().tzinfo)
    for module_id in CORRECT_MODULES:
        perm = OrgRolePermission(
            id=uuid.uuid4(),
            org_role_id=role.id,
            module_id=module_id,
            can_view=True,
            can_add=(module_id in [46, 49, 51]),  # Full access to Testing, Approvals, Mapping
            can_edit=(module_id in [46, 49, 51]),
            can_delete=(module_id in [46, 49, 51]),
            can_approve=(module_id in [46, 49, 51]),
            can_assign=(module_id in [46, 49, 51]),
            can_export=False,
            can_import=False,
            cts=now,
            mts=now
        )
        db.add(perm)

    print(f'  Added 4 correct permissions')

db.commit()
print('\nDone! Field Tester and Lab Tester now have only 4 modules.')
