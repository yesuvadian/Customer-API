"""
Fix TesterRoleModuleRequirement to only require Testing module
Remove Testing Request Approvals from requirement - testers don't need approval permissions
"""
from database import SessionLocal
from models import TesterRoleModuleRequirement, Module

db = SessionLocal()

try:
    print("=" * 80)
    print("FIXING TESTER ROLE MODULE REQUIREMENTS")
    print("=" * 80)

    # Get Testing module
    testing_module = db.query(Module).filter(Module.name == 'Testing').first()

    if not testing_module:
        print("[ERROR] Testing module not found")
        exit(1)

    print(f"[OK] Found Testing module (id: {testing_module.id})")

    # Update the global tester requirement config
    config = db.query(TesterRoleModuleRequirement).filter(
        TesterRoleModuleRequirement.organization_id.is_(None),
        TesterRoleModuleRequirement.is_active == True
    ).first()

    if config:
        print(f"\n[INFO] Current required modules: {config.required_module_ids}")

        # Set to only Testing module
        config.required_module_ids = [testing_module.id]
        config.description = (
            "Global default: Roles must have full permissions (view, add, edit) on "
            "Testing module to qualify as tester roles"
        )

        db.commit()

        print(f"[OK] Updated required modules: {config.required_module_ids}")
        print(f"[OK] New description: {config.description}")
    else:
        print("[WARN] No global tester requirement config found")

    print("\n" + "=" * 80)
    print("SUCCESS: Tester role requirements updated")
    print("Testers now only need Testing module access (not approval permissions)")
    print("=" * 80)

except Exception as e:
    print(f"\nERROR: {e}")
    db.rollback()
    raise
finally:
    db.close()
