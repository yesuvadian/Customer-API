# drop_tables.py
# Drops all repair workflow tables in the correct dependency order.
# Safe to run on a dev DB for a clean reset before re-seeding.
from dotenv import load_dotenv
load_dotenv()

import psycopg2, os

conn = psycopg2.connect(
    host=os.getenv("DB_HOST"),
    port=os.getenv("DB_PORT"),
    dbname=os.getenv("DB_NAME"),
    user=os.getenv("DB_USER"),
    password=os.getenv("DB_PASSWORD"),
)
conn.autocommit = True
cur = conn.cursor()

REPAIR_TABLES = [
    "repair_stage_audit_logs",
    "repair_stage_documents",
    "repair_stage_data",
    "repair_stage_instances",
    "repair_workflows",
    "repair_stage_transitions",
    "repair_stage_roles",
    "repair_stage_templates",
    "repair_stage_definitions",
    "repair_workflow_definitions",
]

print("=" * 60)
print("  DROPPING REPAIR WORKFLOW TABLES")
print("=" * 60)

for table in REPAIR_TABLES:
    cur.execute(f"DROP TABLE IF EXISTS {table} CASCADE;")
    print(f"  [OK] Dropped: {table}")

cur.close()
conn.close()

print("\n[DONE] All repair tables dropped.")
print("       Run: python create_tables.py && python seed.py")
