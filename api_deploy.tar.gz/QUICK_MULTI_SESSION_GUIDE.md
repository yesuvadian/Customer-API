# Quick Multi-Session Testing Guide

## 🎯 What Changed

**ONE LINE SUMMARY**: Results now link to sessions instead of just requests, enabling "Session 1 passed, Session 2 failed" tracking.

---

## 🔌 API Usage

### Create Result for Specific Session

**Before** (tied to request only):
```json
POST /testing/{request_id}/results/structured
{
  "template_key": "maintenance_report",
  "test_data": {"voltage": 220, "current": 5},
  "overall_result": "pass"
}
```

**After** (tied to specific session):
```json
POST /testing/{request_id}/results/structured
{
  "template_key": "maintenance_report",
  "test_data": {"voltage": 220, "current": 5},
  "overall_result": "pass",
  "test_session_id": "uuid-of-session-1"  ← NEW
}
```

### Example: Multi-Session Test with Different Results

```bash
# Session 1 - Morning test (PASS)
curl -X POST http://localhost:8000/testing/req-123/results/structured \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "template_key": "load_test",
    "test_data": {"max_load": 100, "actual_load": 95},
    "overall_result": "pass",
    "test_session_id": "session-morning-uuid"
  }'

# Session 2 - Evening test (FAIL)
curl -X POST http://localhost:8000/testing/req-123/results/structured \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "template_key": "load_test",
    "test_data": {"max_load": 100, "actual_load": 105},
    "overall_result": "fail",
    "test_session_id": "session-evening-uuid"
  }'
```

**Result**: Two separate results stored - clear per-session tracking ✅

---

## 🗃️ Database Schema

### Updated Table Structure

```sql
CREATE TABLE test_results (
  id UUID PRIMARY KEY,
  testing_request_id UUID NOT NULL,
  test_session_id UUID,  -- ← NEW: Links to specific session
  test_data JSONB,
  overall_result VARCHAR(20),
  -- ... other fields ...
  
  FOREIGN KEY (testing_request_id) REFERENCES testing_requests(id),
  FOREIGN KEY (test_session_id) REFERENCES test_sessions(id) ON DELETE SET NULL
);

CREATE INDEX idx_test_results_session_id ON test_results(test_session_id);
```

### Query Results by Session

```sql
-- Get all results for a session
SELECT * FROM test_results 
WHERE test_session_id = 'session-uuid';

-- Get results grouped by session for a request
SELECT 
  ts.session_number,
  ts.session_name,
  tr.overall_result,
  tr.tested_at
FROM test_results tr
JOIN test_sessions ts ON tr.test_session_id = ts.id
WHERE tr.testing_request_id = 'request-uuid'
ORDER BY ts.session_number;
```

---

## 🔄 Backward Compatibility

### Legacy Results (No Session)
```sql
-- Existing results with test_session_id = NULL still work
SELECT * FROM test_results WHERE test_session_id IS NULL;
```

### Migration Strategy
```sql
-- Optional: Link existing results to their sessions
UPDATE test_results r
SET test_session_id = (
  SELECT s.id FROM test_sessions s 
  WHERE s.testing_request_id = r.testing_request_id
  ORDER BY s.completed_at DESC 
  LIMIT 1
)
WHERE r.test_session_id IS NULL;
```

---

## 📱 Flutter Integration

### Update Result Submission

```dart
// In your result submission code:
await _testingProvider.submitStructuredResult(
  requestId: requestId,
  templateKey: templateKey,
  testData: formData,
  overallResult: overallResult,
  testSessionId: currentSessionId,  // ← Add this
);
```

### Provider Method
```dart
// test_session_provider.dart
Future<void> submitStructuredResult({
  required String requestId,
  required String templateKey,
  required Map<String, dynamic> testData,
  required String overallResult,
  String? testSessionId,  // ← Add this parameter
}) async {
  final response = await _dio.post(
    '/testing/$requestId/results/structured',
    data: {
      'template_key': templateKey,
      'test_data': testData,
      'overall_result': overallResult,
      'test_session_id': testSessionId,  // ← Pass to API
    },
  );
  
  // Handle response
}
```

---

## 🧪 Testing

### Test Case 1: Create Result with Session
```bash
# 1. Create a test session
curl -X POST http://localhost:8000/testing_requests/req-123/sessions \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"session_number": 1, "session_name": "Day 1"}'

# Response: {"id": "session-uuid", ...}

# 2. Submit result linked to session
curl -X POST http://localhost:8000/testing/req-123/results/structured \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "template_key": "test",
    "test_data": {},
    "test_session_id": "session-uuid"
  }'

# 3. Verify result is linked
curl http://localhost:8000/testing/req-123/results | jq '.[] | {id, test_session_id}'
```

### Test Case 2: Legacy Single-Session
```bash
# Submit without test_session_id (backward compatible)
curl -X POST http://localhost:8000/testing/req-456/results/structured \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "template_key": "test",
    "test_data": {}
  }'

# Result: test_session_id will be NULL ✅
```

---

## 📊 Reporting

### Session Results Summary
```sql
-- Show pass/fail by session
SELECT 
  tr.testing_request_id,
  ts.session_number,
  ts.session_name,
  COUNT(*) as total_results,
  COUNT(CASE WHEN tr.overall_result = 'pass' THEN 1 END) as passed,
  COUNT(CASE WHEN tr.overall_result = 'fail' THEN 1 END) as failed
FROM test_results tr
JOIN test_sessions ts ON tr.test_session_id = ts.id
GROUP BY tr.testing_request_id, ts.session_number, ts.session_name
ORDER BY ts.session_number;
```

---

## 🚀 Deployment Checklist

- [ ] Run migration: `psql -f migrations/add_test_session_id_to_results.sql`
- [ ] Verify column: `\d test_results` shows `test_session_id`
- [ ] Deploy backend code
- [ ] Test API endpoint with/without `test_session_id`
- [ ] Update Flutter app to pass `test_session_id`
- [ ] Verify per-session result tracking works

---

## 💡 Key Benefits

1. **Per-Session Tracking**: "Session 1 passed, Session 2 failed" now possible
2. **Result History**: See which session produced which result
3. **Backward Compatible**: Existing single-session workflows unaffected
4. **Query Flexibility**: Filter results by session, request, or both
5. **Audit Trail**: Complete history of multi-day testing outcomes

---

## 📞 Support

- Backend docs: `MULTI_SESSION_GAPS_FIXED.md`
- Flutter UI fixes: `FLUTTER_UI_FIXES_REQUIRED.md`
- Migration script: `migrations/add_test_session_id_to_results.sql`
