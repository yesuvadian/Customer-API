"""
Fix Field Tester role permissions - remove incorrect bulk VIEW grant.
Only keep Testing Requests (45), Testing (46), Testing Request Approvals (49), Tester Mapping (51).
Add Equipment (58), Dashboard (21), Notifications (59), Reports (60) as per proper tester role.
"""

from database import get_db
from models import OrgRole, OrgRolePermission, Module
import uuid
from datetime import datetime

def fix_permissions():
    db = next(get_db())

    # Get Field Tester and Lab Tester roles for KPTCL
    kptcl_org_id = '29e36785-97db-4bbd-b0b8-b3609a56afb2'

    tester_roles = db.query(OrgRole).filter(
        OrgRole.organization_id == kptcl_org_id,
        OrgRole.name.in_(['Field Tester', 'Lab Tester'])
    ).all()

    if not tester_roles:
        print("[ERROR] Field Tester / Lab Tester roles not found")
        return

    # Correct module permissions for testers
    CORRECT_PERMISSIONS = {
        45: {"name": "Testing Requests", "can_view": True},  # View only
        46: {"name": "Testing", "can_view": True, "can_add": True, "can_edit": True, "can_delete": True, "can_approve": True, "can_assign": True},  # Full access
        49: {"name": "Testing Request Approvals", "can_view": True, "can_add": True, "can_edit": True, "can_delete": True, "can_approve": True, "can_assign": True},  # Full access
        51: {"name": "Tester Mapping", "can_view": True, "can_add": True, "can_edit": True, "can_delete": True, "can_approve": True, "can_assign": True},  # Full access
        58: {"name": "Equipment", "can_view": True},  # View equipment register
        21: {"name": "Dashboard", "can_view": True},  # View dashboard
        59: {"name": "Notifications", "can_view": True},  # View notifications
        60: {"name": "Reports", "can_view": True, "can_export": True},  # View + export reports
    }

    for role in tester_roles:
        print(f"\nFixing permissions for: {role.name} (ID: {role.id})")

        # Delete ALL existing permissions
        deleted = db.query(OrgRolePermission).filter(
            OrgRolePermission.org_role_id == role.id
        ).delete()
        print(f"  Deleted {deleted} incorrect permissions")

        # Add correct permissions
        now = datetime.now(datetime.now().astimezone().tzinfo)
        for module_id, perm_config in CORRECT_PERMISSIONS.items():
            perm = OrgRolePermission(
                id=uuid.uuid4(),
                org_role_id=role.id,
                module_id=module_id,
                can_view=perm_config.get("can_view", False),
                can_add=perm_config.get("can_add", False),
                can_edit=perm_config.get("can_edit", False),
                can_delete=perm_config.get("can_delete", False),
                can_approve=perm_config.get("can_approve", False),
                can_assign=perm_config.get("can_assign", False),
                can_export=perm_config.get("can_export", False),
                can_import=perm_config.get("can_import", False),
                cts=now,
                mts=now
            )
            db.add(perm)
            print(f"  Added: {perm_config['name']}")

        db.commit()
        print(f"  ✅ {len(CORRECT_PERMISSIONS)} correct permissions applied")

if __name__ == "__main__":
    fix_permissions()
