# SEACMS-AI Role Reconciliation Plan

## Executive Summary

**Objective**: Align current role structure with SRS v1.3 requirements to enable designation-specific notifications, reports, and multi-level approval chains.

**Current State**: 16 roles (9 global + 7 org-specific), functional coverage 100%, designation-specific coverage 40%

**Target State**: 23 roles (9 global + 14 org-specific), full SRS compliance for role-based features

**Timeline**: 3 phases over 2-3 weeks

**Effort**: ~40 hours total (8h Phase 1, 16h Phase 2, 16h Phase 3)

---

## Phase 1: Role Definitions & Basic Provisioning (Week 1, Days 1-2)

### Objective
Add 7 missing SRS-specified roles to the system and provision for KPTCL organization

### Tasks

#### 1.1 Update Role Templates (2 hours)
**File**: `seed.py`

Add to global role templates:
```python
# Around line 143, after existing Originator/Approver roles
{
    "name": "AEE Maintenance",
    "description": "Assistant Executive Engineer - Field-level maintenance responsible officer"
},
{
    "name": "EE TLSS",
    "description": "Executive Engineer - Transmission Line & Substation primary reviewer"
},
{
    "name": "SEE W&M",
    "description": "Superintending Engineer - Works & Maintenance circle supervisor"
},
{
    "name": "EE RT",
    "description": "Executive Engineer - Research & Testing"
},
{
    "name": "SEE RT",
    "description": "Superintending Engineer - Research & Testing"
},
{
    "name": "CEE Transmission Zone",
    "description": "Chief Engineer Executive - Transmission zone management"
},
{
    "name": "CEE RT&R&D",
    "description": "Chief Engineer Executive - Research Testing & R&D"
},
```

#### 1.2 Map Default Permissions (3 hours)
**File**: `seed.py` (privileges section, around line 509)

Define module access for each new role:

```python
# AEE Maintenance - Field supervisor
{
    "role": "AEE Maintenance",
    "permissions": [
        {"module": "Dashboard", "can_view": True},
        {"module": "Testing Requests", "can_view": True, "can_add": True, "can_edit": True},
        {"module": "Testing", "can_view": True, "can_add": True},
        {"module": "Testing Request Approvals", "can_view": True, "can_approve": True},
        {"module": "Equipment", "can_view": True, "can_search": True},
        {"module": "Notifications", "can_view": True},
        {"module": "Reports", "can_view": True, "can_export": True},
    ]
},

# EE TLSS - Primary reviewer
{
    "role": "EE TLSS",
    "permissions": [
        {"module": "Dashboard", "can_view": True},
        {"module": "EE TLSS Dashboard", "can_view": True},  # Dedicated dashboard
        {"module": "Testing Requests", "can_view": True, "can_add": True, "can_edit": True},
        {"module": "Testing", "can_view": True, "can_add": True, "can_edit": True},
        {"module": "Testing Request Approvals", "can_view": True, "can_approve": True, "can_assign": True},
        {"module": "Equipment", "can_view": True, "can_add": True, "can_edit": True},
        {"module": "Notifications", "can_view": True},
        {"module": "Reports", "can_view": True, "can_export": True},
        {"module": "Request Quote", "can_view": True},
        {"module": "Quotes", "can_view": True},
        {"module": "Sales Orders", "can_view": True},
    ]
},

# SEE W&M - Circle supervisor
{
    "role": "SEE W&M",
    "permissions": [
        {"module": "Dashboard", "can_view": True},
        {"module": "EE TLSS Dashboard", "can_view": True},  # Supervisory view
        {"module": "Testing Requests", "can_view": True},
        {"module": "Testing", "can_view": True},
        {"module": "Testing Request Approvals", "can_view": True, "can_approve": True},
        {"module": "Equipment", "can_view": True},
        {"module": "Notifications", "can_view": True},
        {"module": "Reports", "can_view": True, "can_export": True},
        {"module": "Request Quote", "can_view": True, "can_add": True},
        {"module": "Quotes", "can_view": True, "can_approve": True},
        {"module": "Vendor Directory", "can_view": True},
    ]
},

# EE RT - Research & Testing
{
    "role": "EE RT",
    "permissions": [
        {"module": "Dashboard", "can_view": True},
        {"module": "Testing Requests", "can_view": True, "can_add": True},
        {"module": "Testing", "can_view": True, "can_add": True, "can_edit": True},
        {"module": "Testing Request Approvals", "can_view": True, "can_approve": True},
        {"module": "Test Template Management", "can_view": True, "can_edit": True},
        {"module": "Equipment", "can_view": True, "can_add": True, "can_edit": True},
        {"module": "Reports", "can_view": True, "can_export": True},
    ]
},

# SEE RT - Senior Research & Testing
{
    "role": "SEE RT",
    "permissions": [
        {"module": "Dashboard", "can_view": True},
        {"module": "Testing Requests", "can_view": True},
        {"module": "Testing", "can_view": True},
        {"module": "Testing Request Approvals", "can_view": True, "can_approve": True},
        {"module": "Test Template Management", "can_view": True, "can_edit": True},
        {"module": "Equipment", "can_view": True},
        {"module": "Reports", "can_view": True, "can_export": True},
        {"module": "Vendor Directory", "can_view": True},
    ]
},

# CEE Transmission Zone - Zone management
{
    "role": "CEE Transmission Zone",
    "permissions": [
        {"module": "Dashboard", "can_view": True},
        {"module": "EE TLSS Dashboard", "can_view": True},
        {"module": "Testing Requests", "can_view": True},
        {"module": "Testing", "can_view": True},
        {"module": "Testing Request Approvals", "can_view": True, "can_approve": True},
        {"module": "Equipment", "can_view": True},
        {"module": "Notifications", "can_view": True},
        {"module": "Reports", "can_view": True, "can_export": True},
        {"module": "Request Quote", "can_view": True, "can_approve": True},
        {"module": "Quotes", "can_view": True, "can_approve": True},
        {"module": "Sales Orders", "can_view": True},
        {"module": "Vendor Directory", "can_view": True},
    ]
},

# CEE RT&R&D - Research & Development
{
    "role": "CEE RT&R&D",
    "permissions": [
        {"module": "Dashboard", "can_view": True},
        {"module": "Testing Requests", "can_view": True},
        {"module": "Testing", "can_view": True},
        {"module": "Testing Request Approvals", "can_view": True},
        {"module": "Test Template Management", "can_view": True, "can_add": True, "can_edit": True, "can_delete": True},
        {"module": "Equipment", "can_view": True, "can_add": True, "can_edit": True},
        {"module": "Reports", "can_view": True, "can_export": True},
        {"module": "Vendor Directory", "can_view": True},
    ]
},
```

#### 1.3 Create Test Users (2 hours)
**File**: `seed.py` (KPTCL users section, around line 2700)

Add test users for each new role:
```python
# Add after existing KPTCL users
{
    "email": "aee.maintenance@kptcl.com",
    "password": "admin123",
    "firstname": "AEE",
    "lastname": "Maintenance",
    "phone": "+91-9900000010",
    "role_name": "AEE Maintenance",
    "employee_id": "KPTCL-AEE-M-001",
},
{
    "email": "ee.tlss@kptcl.com",
    "password": "admin123",
    "firstname": "EE",
    "lastname": "TLSS",
    "phone": "+91-9900000011",
    "role_name": "EE TLSS",
    "employee_id": "KPTCL-EE-TLSS-001",
},
{
    "email": "see.wm@kptcl.com",
    "password": "admin123",
    "firstname": "SEE",
    "lastname": "W&M",
    "phone": "+91-9900000012",
    "role_name": "SEE W&M",
    "employee_id": "KPTCL-SEE-WM-001",
},
{
    "email": "ee.rt@kptcl.com",
    "password": "admin123",
    "firstname": "EE",
    "lastname": "RT",
    "phone": "+91-9900000013",
    "role_name": "EE RT",
    "employee_id": "KPTCL-EE-RT-001",
},
{
    "email": "see.rt@kptcl.com",
    "password": "admin123",
    "firstname": "SEE",
    "lastname": "RT",
    "phone": "+91-9900000014",
    "role_name": "SEE RT",
    "employee_id": "KPTCL-SEE-RT-001",
},
{
    "email": "cee.zone@kptcl.com",
    "password": "admin123",
    "firstname": "CEE",
    "lastname": "Transmission Zone",
    "phone": "+91-9900000015",
    "role_name": "CEE Transmission Zone",
    "employee_id": "KPTCL-CEE-TZ-001",
},
{
    "email": "cee.rtrd@kptcl.com",
    "password": "admin123",
    "firstname": "CEE",
    "lastname": "RT&R&D",
    "phone": "+91-9900000016",
    "role_name": "CEE RT&R&D",
    "employee_id": "KPTCL-CEE-RTRD-001",
},
```

#### 1.4 Run Seed Script (1 hour)
```bash
# Drop and recreate database
python -c "from database import engine; from models import Base; Base.metadata.drop_all(engine); Base.metadata.create_all(engine)"

# Run seed
python seed.py
```

**Validation**:
- [ ] 7 new roles appear in `org_roles` table for KPTCL
- [ ] 7 new users created with correct role assignments
- [ ] Default permissions created in `org_role_permissions`
- [ ] Login test for each new user email

**Deliverables**:
- ✅ 7 new roles provisioned
- ✅ 7 test users created
- ✅ Basic permissions configured

---

## Phase 2: Notification & Report Configuration (Week 1, Days 3-5 + Week 2, Days 1-2)

### Objective
Update notification templates and report definitions to use designation-specific roles

### Tasks

#### 2.1 Update Notification Templates (8 hours)
**File**: Database seed or migration script

Update `notification_templates.recipient_roles` for 8 key events:

```sql
-- Test Due Reminder (15 days)
UPDATE notification_templates
SET recipient_roles = '["Originator", "AEE Maintenance"]'::jsonb
WHERE event_type = 'test_due_15_days';

-- Test Due Reminder (7 days)
UPDATE notification_templates
SET recipient_roles = '["Originator", "EE TLSS"]'::jsonb
WHERE event_type = 'test_due_7_days';

-- Test Overdue
UPDATE notification_templates
SET recipient_roles = '["EE TLSS", "SEE W&M"]'::jsonb
WHERE event_type = 'test_overdue';

-- Test Overdue Escalation
UPDATE notification_templates
SET recipient_roles = '["CEE Transmission Zone"]'::jsonb
WHERE event_type = 'test_overdue_escalation';

-- CRITICAL Result
UPDATE notification_templates
SET recipient_roles = '["EE TLSS", "SEE W&M", "CEE Transmission Zone"]'::jsonb
WHERE event_type = 'critical_result';

-- Remedial Action Due
UPDATE notification_templates
SET recipient_roles = '["Field Tester", "EE TLSS"]'::jsonb
WHERE event_type = 'remedial_action_due';

-- Equipment Replacement
UPDATE notification_templates
SET recipient_roles = '["EE TLSS", "SEE W&M", "CEE Transmission Zone"]'::jsonb
WHERE event_type = 'equipment_replacement';

-- Overhaul Recommendation
UPDATE notification_templates
SET recipient_roles = '["AEE Maintenance", "EE TLSS", "SEE W&M"]'::jsonb
WHERE event_type = 'overhaul_recommendation';
```

**Implementation Steps**:
1. Check if notification templates exist (they should from seed)
2. If not, provision notification templates first
3. Create migration script: `update_notification_roles.py`
4. Run migration
5. Verify in database

#### 2.2 Update Report Definitions (4 hours)
**File**: Database seed or migration script

Update `report_definitions.recipient_roles` for 9 standard reports:

```sql
-- Equipment Failure Report
UPDATE report_definitions
SET recipient_roles = '["SEE W&M", "CEE Transmission Zone"]'::jsonb
WHERE name = 'Equipment Failure Report';

-- Transformer Repair Status
UPDATE report_definitions
SET recipient_roles = '["EE TLSS", "SEE W&M", "CEE Transmission Zone", "CEE RT&R&D"]'::jsonb
WHERE name = 'Transformer Repair Status Report';

-- Test Compliance Status
UPDATE report_definitions
SET recipient_roles = '["SEE W&M", "CEE Transmission Zone"]'::jsonb
WHERE name = 'Test Compliance Status Report';

-- Overdue Test Report
UPDATE report_definitions
SET recipient_roles = '["EE TLSS", "SEE W&M", "CEE Transmission Zone"]'::jsonb
WHERE name = 'Overdue Test Report';

-- ALERT/CRITICAL Equipment
UPDATE report_definitions
SET recipient_roles = '["EE TLSS", "SEE W&M", "CEE Transmission Zone"]'::jsonb
WHERE name = 'ALERT/CRITICAL Equipment Report';

-- Remedial Action Pending
UPDATE report_definitions
SET recipient_roles = '["EE TLSS", "SEE W&M"]'::jsonb
WHERE name = 'Remedial Action Pending Report';

-- Vendor Performance Ranking
UPDATE report_definitions
SET recipient_roles = '["CEE Transmission Zone", "Purchaser"]'::jsonb
WHERE name = 'Vendor Performance Ranking Report';

-- Repairer Performance Ranking
UPDATE report_definitions
SET recipient_roles = '["CEE Transmission Zone", "CEE RT&R&D"]'::jsonb
WHERE name = 'Repairer Performance Ranking Report';

-- TA&QC Observation Compliance
UPDATE report_definitions
SET recipient_roles = '["EE TLSS", "SEE W&M"]'::jsonb
WHERE name = 'TA&QC Observation Compliance Report';
```

#### 2.3 Implement Role-Based Report Filtering (4 hours)
**File**: `routers/reporting.py`

Add role-based filtering to report list endpoint:

```python
@router.get("/reports/definitions")
async def list_report_definitions(
    active_only: bool = True,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Get user's org roles
    user_roles = db.query(OrgRole).join(OrgUserRole).filter(
        OrgUserRole.user_id == current_user['id']
    ).all()
    
    user_role_names = [role.name for role in user_roles]
    
    # Fetch definitions
    query = db.query(ReportDefinition)
    if active_only:
        query = query.filter(ReportDefinition.is_active == True)
    
    definitions = query.all()
    
    # Filter by recipient_roles
    filtered = []
    for defn in definitions:
        recipient_roles = defn.recipient_roles or []
        # Show if user has any matching role OR user is Admin
        if 'Admin' in user_role_names or any(role in recipient_roles for role in user_role_names):
            filtered.append(defn)
    
    return filtered
```

**Deliverables**:
- ✅ 8 notification templates updated with designation-specific roles
- ✅ 9 report definitions updated with designation-specific roles
- ✅ Role-based report filtering implemented
- ✅ Users only see reports relevant to their designation

---

## Phase 3: Approval Workflow Enhancement (Week 2, Days 3-5)

### Objective
Implement multi-level approval chain matching SRS hierarchy

### Tasks

#### 3.1 Design Approval Chain Data Model (4 hours)
**File**: `models.py`

Add approval chain tracking to `TestingRequest`:

```python
class TestingRequest(Base):
    # ... existing fields ...
    
    # NEW: Multi-level approval chain
    approval_chain = Column(JSONB, nullable=True)
    # Structure:
    # {
    #   "levels": [
    #     {"level": 1, "role": "AEE Maintenance", "status": "approved", "approved_by": UUID, "approved_at": ISO},
    #     {"level": 2, "role": "EE TLSS", "status": "pending", "approved_by": null, "approved_at": null},
    #     {"level": 3, "role": "SEE W&M", "status": "pending", "approved_by": null, "approved_at": null},
    #   ],
    #   "current_level": 2,
    #   "requires_escalation": false,
    #   "escalation_reason": null
    # }
    
    current_approval_level = Column(Integer, default=1)
    requires_escalation = Column(Boolean, default=False)
```

#### 3.2 Implement Approval Chain Service (6 hours)
**File**: `services/approval_chain_service.py` (NEW)

```python
class ApprovalChainService:
    
    # Standard chain for testing requests
    DEFAULT_CHAIN = [
        {"level": 1, "role": "AEE Maintenance", "required": False},  # Optional review
        {"level": 2, "role": "EE TLSS", "required": True},           # Primary approval
        {"level": 3, "role": "SEE W&M", "required": False},          # Escalation only
        {"level": 4, "role": "CEE Transmission Zone", "required": False},  # Final escalation
    ]
    
    @staticmethod
    def initialize_chain(request: TestingRequest, evaluation_result: dict = None):
        """Initialize approval chain based on test result severity."""
        chain = copy.deepcopy(ApprovalChainService.DEFAULT_CHAIN)
        
        # Auto-escalate CRITICAL results to SEE level
        if evaluation_result and evaluation_result.get('overall') == 'CRITICAL':
            chain[2]['required'] = True  # SEE W&M approval required
            request.requires_escalation = True
        
        # Auto-escalate high-value procurement to CEE level
        if request.estimated_cost and request.estimated_cost > 1000000:
            chain[3]['required'] = True  # CEE approval required
        
        request.approval_chain = {"levels": chain, "current_level": 1}
        return chain
    
    @staticmethod
    def approve_current_level(request: TestingRequest, approver_id: UUID, db: Session):
        """Approve current level and advance to next required level."""
        chain = request.approval_chain
        current_level = chain['current_level']
        
        # Mark current level as approved
        for level_config in chain['levels']:
            if level_config['level'] == current_level:
                level_config['status'] = 'approved'
                level_config['approved_by'] = str(approver_id)
                level_config['approved_at'] = datetime.now(timezone.utc).isoformat()
                break
        
        # Find next required level
        next_required = None
        for level_config in chain['levels']:
            if level_config['level'] > current_level and level_config['required']:
                next_required = level_config['level']
                break
        
        if next_required:
            chain['current_level'] = next_required
            request.current_approval_level = next_required
            request.status = 'pending_approval'
        else:
            # All required approvals complete
            request.status = 'approved'
            request.current_approval_level = None
        
        request.approval_chain = chain
        db.commit()
    
    @staticmethod
    def can_approve(request: TestingRequest, user_roles: list[str]) -> bool:
        """Check if user has permission to approve at current level."""
        chain = request.approval_chain
        if not chain:
            return False
        
        current_level = chain['current_level']
        for level_config in chain['levels']:
            if level_config['level'] == current_level:
                required_role = level_config['role']
                return required_role in user_roles
        
        return False
    
    @staticmethod
    def escalate(request: TestingRequest, escalation_reason: str, db: Session):
        """Force escalation to next level (e.g., overdue or critical)."""
        chain = request.approval_chain
        current_level = chain['current_level']
        
        # Find next level in hierarchy
        next_level = current_level + 1
        if next_level <= len(chain['levels']):
            chain['levels'][next_level - 1]['required'] = True
            chain['current_level'] = next_level
            request.current_approval_level = next_level
            request.requires_escalation = True
            request.approval_chain = chain
            db.commit()
            
            # Send escalation notification
            from services.notification_service import NotificationService
            NotificationService(db).fire(
                event_type='approval_escalated',
                context={'reason': escalation_reason, 'level': next_level},
                organization_id=request.organization_id,
                source_id=request.id,
                source_type='testing_request'
            )
```

#### 3.3 Update Approval Router (4 hours)
**File**: `routers/approvals.py`

Integrate approval chain service:

```python
@router.post("/approvals/{request_id}/approve")
async def approve_request(
    request_id: UUID,
    approval_data: ApprovalSchema,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    request = db.query(TestingRequest).filter(TestingRequest.id == request_id).first()
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    
    # Get user roles
    user_roles = [r.name for r in db.query(OrgRole).join(OrgUserRole).filter(
        OrgUserRole.user_id == current_user['id']
    ).all()]
    
    # Check if user can approve at current level
    if not ApprovalChainService.can_approve(request, user_roles):
        raise HTTPException(status_code=403, detail="Not authorized to approve at this level")
    
    # Process approval
    ApprovalChainService.approve_current_level(request, current_user['id'], db)
    
    return {"message": "Approved successfully", "status": request.status}
```

#### 3.4 Update Frontend Approval UI (2 hours)
**File**: `lib/pages/testing/approval_detail.dart`

Display approval chain and current level:

```dart
// Show approval chain status
Widget _buildApprovalChain(Map<String, dynamic> approvalChain) {
  final levels = approvalChain['levels'] as List? ?? [];
  final currentLevel = approvalChain['current_level'] as int? ?? 1;
  
  return Column(
    children: levels.map((level) {
      final levelNum = level['level'] as int;
      final role = level['role'] as String;
      final status = level['status'] as String? ?? 'pending';
      final isCurrent = levelNum == currentLevel;
      
      return ListTile(
        leading: Icon(
          status == 'approved' ? Icons.check_circle : Icons.pending,
          color: status == 'approved' ? Colors.green : (isCurrent ? Colors.orange : Colors.grey),
        ),
        title: Text('Level $levelNum: $role'),
        subtitle: Text(status.toUpperCase()),
        trailing: isCurrent ? Badge(label: Text('Current')) : null,
      );
    }).toList(),
  );
}
```

**Deliverables**:
- ✅ Multi-level approval chain data model
- ✅ Approval chain service with escalation logic
- ✅ Updated approval router with role-based checks
- ✅ Frontend UI showing approval chain status
- ✅ Auto-escalation for CRITICAL results

---

## Phase 4: Testing & Validation (Week 3)

### Test Scenarios

#### Scenario 1: Role-Based Notification
1. Login as Field Tester
2. Submit test with CRITICAL result
3. Verify notifications sent to: EE TLSS, SEE W&M, CEE Transmission Zone
4. Login as each recipient and verify notification received

#### Scenario 2: Role-Based Report Access
1. Login as EE TLSS
2. Navigate to Reports
3. Verify only sees reports where "EE TLSS" is in recipient_roles
4. Repeat for SEE W&M and CEE roles

#### Scenario 3: Multi-Level Approval
1. Login as Field Tester
2. Submit NORMAL result test
3. Verify approval required from: AEE Maintenance → EE TLSS
4. Submit CRITICAL result test
5. Verify approval required from: AEE Maintenance → EE TLSS → SEE W&M

#### Scenario 4: Escalation
1. Login as EE TLSS
2. Submit test with ALERT result
3. Wait 7 days (or simulate overdue)
4. Verify auto-escalation to SEE W&M
5. Verify escalation notification sent to CEE Transmission Zone

**Test Coverage**: 80%+ for role-based features

---

## Rollout Plan

### Pre-Production Checklist
- [ ] All 7 roles provisioned in KPTCL org
- [ ] Test users created for each role
- [ ] Permissions validated for each role
- [ ] Notification templates updated (8 events)
- [ ] Report definitions updated (9 reports)
- [ ] Approval chain tested for NORMAL, ALERT, CRITICAL results
- [ ] Role-based report filtering working
- [ ] Frontend displays approval chain correctly

### Production Deployment Steps

1. **Backup Database** (30 min)
   ```bash
   pg_dump -h localhost -U postgres -d seacms_prod > backup_pre_roles_$(date +%Y%m%d).sql
   ```

2. **Deploy Code** (15 min)
   - Merge role reconciliation branch to main
   - Deploy backend API
   - Deploy Flutter web app

3. **Run Database Migration** (15 min)
   ```bash
   python seed.py --roles-only  # Only provision new roles
   python update_notification_roles.py
   python update_report_roles.py
   ```

4. **User Assignment** (Manual, 2 hours)
   - Work with KPTCL admin to map existing users to new roles
   - Update org_user_role table
   - Remove old generic role assignments

5. **Smoke Test** (30 min)
   - Login as each new role
   - Verify dashboard access
   - Submit test request and verify approval flow
   - Check notification delivery

6. **Monitor** (48 hours)
   - Track notification delivery success rate
   - Monitor approval workflow completion
   - Check for permission errors in logs

### Rollback Plan
If critical issues found:
1. Restore database backup
2. Revert code deployment
3. Investigate issues in dev environment
4. Fix and re-test before re-deployment

---

## Success Metrics

| Metric | Baseline | Target | Measurement |
|---|---|---|---|
| **Role Coverage** | 40% | 85% | Count of SRS-specified roles implemented |
| **Notification Accuracy** | 60% (generic roles) | 95% (designation-specific) | % notifications sent to correct designation |
| **Report Access Accuracy** | 0% (all see all) | 90% (role-filtered) | % users seeing only relevant reports |
| **Approval SLA** | 5 days avg | 3 days avg | Reduced due to clear role assignment |
| **User Satisfaction** | Baseline survey | +20% | Post-deployment survey |

---

## Risk Mitigation

| Risk | Impact | Probability | Mitigation |
|---|---|---|---|
| **Existing users lose access** | High | Medium | Maintain Admin role assignments, gradual migration |
| **Notification spam** | Medium | Low | Test in dev, add digest mode for multiple alerts |
| **Approval bottleneck** | High | Medium | Configure SLA reminders, enable delegation |
| **Permission conflicts** | Medium | Low | Comprehensive permission testing matrix |
| **User confusion** | Medium | High | Training documentation, role description tooltips |

---

## Post-Implementation Tasks

1. **User Training** (1 week)
   - Record video walkthrough for each new role
   - Create role-specific quick reference cards
   - Conduct live training session with KPTCL team

2. **Documentation** (3 days)
   - Update API documentation with new role endpoints
   - Document approval chain logic
   - Create admin guide for role management

3. **Monitoring Dashboard** (2 days)
   - Create role usage dashboard
   - Track approval chain completion rates
   - Monitor notification delivery by role

4. **Optimization** (Ongoing)
   - Analyze bottlenecks in approval chain
   - Adjust notification frequency based on feedback
   - Refine report access rules based on usage patterns

---

## Budget Summary

| Phase | Hours | Rate | Cost |
|---|---|---|---|
| Phase 1: Role Provisioning | 8h | - | - |
| Phase 2: Notifications & Reports | 16h | - | - |
| Phase 3: Approval Workflow | 16h | - | - |
| Phase 4: Testing | 8h | - | - |
| Training & Documentation | 24h | - | - |
| **Total** | **72h** | - | - |

---

## Appendix: Quick Reference

### New Role Emails (Test Users)
- aee.maintenance@kptcl.com
- ee.tlss@kptcl.com ⭐ (Most critical)
- see.wm@kptcl.com ⭐ (Most critical)
- ee.rt@kptcl.com
- see.rt@kptcl.com
- cee.zone@kptcl.com
- cee.rtrd@kptcl.com

### Key Files Modified
- `seed.py` - Role definitions and permissions
- `models.py` - Approval chain fields
- `services/approval_chain_service.py` - NEW
- `routers/approvals.py` - Multi-level approval
- `routers/reporting.py` - Role-based filtering

### Migration Scripts
- `update_notification_roles.py` - Notification template update
- `update_report_roles.py` - Report definition update

---

**Plan Owner**: Development Team  
**Stakeholder**: KPTCL Operations  
**Review Date**: End of Week 1  
**Final Approval**: Before Phase 3 deployment
