# Flutter Implementation Guide - Multi-Session Result Linking

**Priority**: 🔴 HIGH  
**Estimated Time**: 3-4 hours  
**Impact**: Critical - enables per-session result tracking

---

## 🎯 Objective

Link test results to specific sessions by passing `test_session_id` when submitting results.

**Before**: All results tied to request → can't distinguish "Session 1 passed, Session 2 failed"  
**After**: Each result linked to its session → clear per-session tracking ✅

---

## 📋 Files to Modify

1. `lib/providers/testing/test_template_provider.dart`
2. `lib/pages/zoho/test_result_form.dart`
3. (Optional) Session navigation files

---

## 🛠️ Step-by-Step Implementation

### Step 1: Update Provider to Accept test_session_id

**File**: `lib/providers/testing/test_template_provider.dart`

**Change 1 - submitStructuredResult() method** (lines ~88-130):

```dart
// BEFORE:
Future<Map<String, dynamic>?> submitStructuredResult({
  required String requestId,
  required String templateKey,
  required Map<String, dynamic> testData,
  String? overallResult,
  String? remarks,
  List<Map<String, dynamic>>? replacementProducts,
}) async {

// AFTER:
Future<Map<String, dynamic>?> submitStructuredResult({
  required String requestId,
  required String templateKey,
  required Map<String, dynamic> testData,
  String? overallResult,
  String? remarks,
  List<Map<String, dynamic>>? replacementProducts,
  String? testSessionId,  // ← ADD THIS
}) async {
```

**Change 2 - Add to payload**:

```dart
// BEFORE:
final payload = {
  'template_key': templateKey,
  'test_data': testData,
  'overall_result': overallResult,
  'remarks': remarks,
  if (replacementProducts != null) 'replacement_products': replacementProducts,
};

// AFTER:
final payload = {
  'template_key': templateKey,
  'test_data': testData,
  'overall_result': overallResult,
  'remarks': remarks,
  if (replacementProducts != null) 'replacement_products': replacementProducts,
  if (testSessionId != null) 'test_session_id': testSessionId,  // ← ADD THIS
};
```

---

**Change 3 - saveAndSubmit() method** (lines ~220-275):

```dart
// BEFORE:
Future<String?> saveAndSubmit({
  required String requestId,
  required String templateKey,
  required Map<String, dynamic> testData,
  String? overallResult,
  String? remarks,
  List<MapEntry<String, Uint8List>>? images,
  List<Map<String, dynamic>>? replacementProducts,
  bool finalize = false,
}) async {

// AFTER:
Future<String?> saveAndSubmit({
  required String requestId,
  required String templateKey,
  required Map<String, dynamic> testData,
  String? overallResult,
  String? remarks,
  List<MapEntry<String, Uint8List>>? images,
  List<Map<String, dynamic>>? replacementProducts,
  bool finalize = false,
  String? testSessionId,  // ← ADD THIS
}) async {
```

**Change 4 - Pass through to submitStructuredResult**:

```dart
// BEFORE:
final result = await submitStructuredResult(
  requestId: requestId,
  templateKey: templateKey,
  testData: testData,
  overallResult: overallResult,
  remarks: remarks,
  replacementProducts: replacementProducts,
);

// AFTER:
final result = await submitStructuredResult(
  requestId: requestId,
  templateKey: templateKey,
  testData: testData,
  overallResult: overallResult,
  remarks: remarks,
  replacementProducts: replacementProducts,
  testSessionId: testSessionId,  // ← ADD THIS
);
```

---

### Step 2: Update UI to Pass test_session_id

**File**: `lib/pages/zoho/test_result_form.dart`

**Change 1 - Add testSessionId to widget constructor**:

```dart
// BEFORE (around line 18):
class TestResultForm extends StatefulWidget {
  final String requestId;
  final int? testTypeId;
  final String? templateKey;
  final String testTypeName;
  final VoidCallback onClose;
  final VoidCallback? onSubmitted;

  const TestResultForm({
    super.key,
    required this.requestId,
    this.testTypeId,
    this.templateKey,
    required this.testTypeName,
    required this.onClose,
    this.onSubmitted,
  }) : assert(testTypeId != null || templateKey != null,
            'Either testTypeId or templateKey must be provided');

// AFTER:
class TestResultForm extends StatefulWidget {
  final String requestId;
  final int? testTypeId;
  final String? templateKey;
  final String testTypeName;
  final VoidCallback onClose;
  final VoidCallback? onSubmitted;
  final String? testSessionId;  // ← ADD THIS

  const TestResultForm({
    super.key,
    required this.requestId,
    this.testTypeId,
    this.templateKey,
    required this.testTypeName,
    required this.onClose,
    this.onSubmitted,
    this.testSessionId,  // ← ADD THIS
  }) : assert(testTypeId != null || templateKey != null,
            'Either testTypeId or templateKey must be provided');
```

---

**Change 2 - Pass to saveAndSubmit()** (around line 1338):

```dart
// BEFORE:
final err = await provider.saveAndSubmit(
  requestId: widget.requestId,
  templateKey: templateKey,
  testData: testData,
  overallResult: effectiveOverall,
  remarks: effectiveRemarks.isEmpty ? null : effectiveRemarks,
  images: _images.isNotEmpty ? _images : null,
  replacementProducts: replacementProducts.isNotEmpty ? replacementProducts : null,
  finalize: finalize,
);

// AFTER:
final err = await provider.saveAndSubmit(
  requestId: widget.requestId,
  templateKey: templateKey,
  testData: testData,
  overallResult: effectiveOverall,
  remarks: effectiveRemarks.isEmpty ? null : effectiveRemarks,
  images: _images.isNotEmpty ? _images : null,
  replacementProducts: replacementProducts.isNotEmpty ? replacementProducts : null,
  finalize: finalize,
  testSessionId: widget.testSessionId,  // ← ADD THIS
);
```

---

### Step 3: Pass testSessionId When Opening Result Form

**Wherever TestResultForm is instantiated**, pass the current session ID.

**Example A - From Session Detail Page**:

```dart
// In test_session_page.dart or similar
ElevatedButton(
  onPressed: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TestResultForm(
          requestId: widget.requestId,
          templateKey: 'template_key_here',
          testTypeName: 'Test Type',
          onClose: () => Navigator.pop(context),
          testSessionId: sessionId,  // ← PASS SESSION ID
        ),
      ),
    );
  },
  child: const Text('Submit Result'),
)
```

**Example B - From Testing Request Detail Page (Multi-Session)**:

```dart
// In testing_request_detail.dart
final sessionProvider = context.read<TestSessionProvider>();
final inProgressSessions = sessionProvider.sessions
    .where((s) => s['status'] == 'in_progress')
    .toList();

String? currentSessionId;
if (inProgressSessions.isNotEmpty) {
  currentSessionId = inProgressSessions.first['id']?.toString();
}

// When opening result form:
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => TestResultForm(
      requestId: requestId,
      templateKey: templateKey,
      testTypeName: testTypeName,
      onClose: () => Navigator.pop(context),
      testSessionId: currentSessionId,  // ← PASS CURRENT SESSION
    ),
  ),
);
```

**Example C - Legacy Single-Session (Backward Compatible)**:

```dart
// For requests without multi-session, pass null
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => TestResultForm(
      requestId: requestId,
      testTypeId: testTypeId,
      testTypeName: testTypeName,
      onClose: () => Navigator.pop(context),
      testSessionId: null,  // ← NULL for legacy single-session
    ),
  ),
);
```

---

## 🧪 Testing

### Test Case 1: Multi-Session Result Linking

1. **Create Multi-Session Request**:
   ```
   - Request with 3 sessions
   - Auto-generate or manually create sessions
   ```

2. **Submit Result for Session 1**:
   ```
   - Start Session 1
   - Open result form (should pass session_1_id)
   - Fill form and save
   - Check backend: result.test_session_id should = session_1_id
   ```

3. **Submit Result for Session 2**:
   ```
   - Complete Session 1
   - Start Session 2
   - Open result form (should pass session_2_id)
   - Fill form and save
   - Check backend: result.test_session_id should = session_2_id
   ```

4. **Verify Per-Session Tracking**:
   ```sql
   -- Backend query
   SELECT 
     tr.id,
     tr.testing_request_id,
     tr.test_session_id,
     ts.session_number,
     tr.overall_result
   FROM test_results tr
   JOIN test_sessions ts ON tr.test_session_id = ts.id
   WHERE tr.testing_request_id = '<request_id>'
   ORDER BY ts.session_number;
   
   -- Should show:
   -- Result 1 → Session 1 (session_number: 1)
   -- Result 2 → Session 2 (session_number: 2)
   ```

---

### Test Case 2: Backward Compatibility (Single-Session)

1. **Create Single-Session Request**:
   ```
   - Request without multi-session flag
   - OR request with total_sessions_planned = 1
   ```

2. **Submit Result**:
   ```
   - Open result form (testSessionId should be null)
   - Fill form and save
   - Check backend: result.test_session_id should = NULL
   ```

3. **Verify Legacy Behavior**:
   ```sql
   -- Backend query
   SELECT id, testing_request_id, test_session_id
   FROM test_results
   WHERE testing_request_id = '<single_session_request_id>';
   
   -- Should show:
   -- test_session_id = NULL (legacy single-session)
   ```

---

### Test Case 3: Draft Save and Reload

1. **Save Draft with Session**:
   ```
   - Start Session 1
   - Open result form
   - Fill partial data
   - Click "Save Draft"
   - Close form
   ```

2. **Reload Draft**:
   ```
   - Reopen result form
   - Verify form pre-fills with saved data
   - Verify session_id is retained
   - Complete and submit
   ```

3. **Verify Result Updated**:
   ```sql
   -- Should update existing result, not create new one
   SELECT COUNT(*) FROM test_results
   WHERE testing_request_id = '<request_id>'
   AND test_session_id = '<session_id>';
   
   -- Should return 1 (not 2)
   ```

---

## 🎯 Expected Outcomes

### Before Implementation ❌
```
Test Results Table:
┌──────────┬──────────────┬────────────────┬────────────┐
│ id       │ request_id   │ test_session_id│ result     │
├──────────┼──────────────┼────────────────┼────────────┤
│ result-1 │ request-123  │ NULL           │ pass       │
│ result-2 │ request-123  │ NULL           │ fail       │
└──────────┴──────────────┴────────────────┴────────────┘
❌ Can't tell which session each result belongs to
```

### After Implementation ✅
```
Test Results Table:
┌──────────┬──────────────┬────────────────┬────────────┐
│ id       │ request_id   │ test_session_id│ result     │
├──────────┼──────────────┼────────────────┼────────────┤
│ result-1 │ request-123  │ session-1-uuid │ pass       │
│ result-2 │ request-123  │ session-2-uuid │ fail       │
└──────────┴──────────────┴────────────────┴────────────┘
✅ Clear per-session tracking!
```

---

## 🐛 Common Issues & Fixes

### Issue 1: testSessionId is always null

**Symptom**: Results saved with test_session_id = NULL even for multi-session requests

**Fix**: Check that `testSessionId` is being passed when opening `TestResultForm`:
```dart
// ❌ WRONG
TestResultForm(
  requestId: requestId,
  // ... missing testSessionId
)

// ✅ CORRECT
TestResultForm(
  requestId: requestId,
  testSessionId: currentSession['id']?.toString(),
)
```

---

### Issue 2: Multiple results created for same session

**Symptom**: Each draft save creates a new result instead of updating existing

**Root Cause**: Backend upsert logic matches on `(request_id, template_key, test_session_id)`. If any of these change, a new result is created.

**Fix**: Ensure `testSessionId` remains consistent between saves:
- Don't switch sessions mid-form
- Pass same session ID when reopening form

---

### Issue 3: Can't find current session

**Symptom**: Don't know which session_id to pass to result form

**Fix**: Get current in-progress session from provider:
```dart
final sessionProvider = context.read<TestSessionProvider>();
await sessionProvider.fetchSessions(requestId);

final currentSession = sessionProvider.sessions
    .where((s) => s['status'] == 'in_progress')
    .firstOrNull;

final testSessionId = currentSession?['id']?.toString();

// Pass to form
TestResultForm(
  requestId: requestId,
  testSessionId: testSessionId,
  // ...
)
```

---

## 📝 Code Review Checklist

Before committing:
- [ ] `test_template_provider.dart` updated with `testSessionId` parameter
- [ ] `submitStructuredResult()` includes `test_session_id` in payload
- [ ] `saveAndSubmit()` passes `testSessionId` through
- [ ] `test_result_form.dart` accepts `testSessionId` in constructor
- [ ] `testSessionId` passed to `provider.saveAndSubmit()`
- [ ] All places that open `TestResultForm` pass `testSessionId`
- [ ] Tested multi-session result linking
- [ ] Tested backward compatibility (single-session)
- [ ] Tested draft save and reload
- [ ] No lint errors

---

## 🎉 Success Criteria

✅ Multi-session requests create separate results per session  
✅ Backend query shows correct `test_session_id` for each result  
✅ Session timeline can show per-session pass/fail status  
✅ Single-session requests still work (test_session_id = NULL)  
✅ Draft results properly update existing row (no duplicates)  
✅ Form reloads with correct data when reopened

---

## 📞 Support

**Backend Reference**: `MULTI_SESSION_GAPS_FIXED.md`  
**Full Review**: `FLUTTER_CODE_REVIEW_FINDINGS.md`  
**Quick Guide**: `QUICK_MULTI_SESSION_GUIDE.md`

**Questions?**
- Check backend API endpoint: `POST /testing/{request_id}/results/structured`
- Verify payload includes `test_session_id` field
- Check database: `SELECT * FROM test_results WHERE test_session_id IS NOT NULL`
