#!/usr/bin/env python3
# Read the file with UTF-8 encoding
with open('services/reporting_service.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace unquoted CategoryMaster and CategoryDetails with quoted versions
content = content.replace('public.CategoryMaster', 'public."CategoryMaster"')
content = content.replace('public.CategoryDetails', 'public."CategoryDetails"')

# Write back with UTF-8
with open('services/reporting_service.py', 'w', encoding='utf-8') as f:
    f.write(content)

print('Updated table names to use quoted identifiers')
