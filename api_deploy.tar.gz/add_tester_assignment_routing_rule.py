"""
Seed: Notification Routing Rule — tester_assigned → @assignee
==============================================================
Inserts a global (org_id = NULL) routing rule that delivers the
"tester_assigned" notification exclusively to the assigned tester by
using the ``@assignee`` system recipient token.

Run once:
    python add_tester_assignment_routing_rule.py

Idempotent — skips insertion if a global rule for ``tester_assigned``
already exists.
"""

from database import get_db
from models import NotificationRoutingRule


def seed():
    db = next(get_db())
    try:
        # Check if already seeded
        existing = (
            db.query(NotificationRoutingRule)
            .filter(
                NotificationRoutingRule.event_type == "tester_assigned",
                NotificationRoutingRule.organization_id.is_(None),
            )
            .first()
        )

        if existing:
            print(
                f"[SKIP] Global routing rule for 'tester_assigned' already exists "
                f"(id={existing.id})"
            )
            return

        rule = NotificationRoutingRule(
            organization_id            = None,          # global default
            event_type                 = "tester_assigned",
            label                      = "Notify assigned tester (email + in-app)",
            applicable_workflow_types  = [],            # all workflows
            applicable_equipment_types = [],            # all equipment types
            applicable_test_types      = [],            # all test types
            applicable_status_from     = None,
            applicable_status_to       = "assigned",
            channels_enabled           = ["email", "inapp"],
            # @assignee resolves to TestingRequest.assigned_tester_id at
            # fire()-time — only the specific tester receives this notification.
            recipient_roles_override   = ["@assignee"],
            priority                   = 10,
            is_active                  = True,
        )
        db.add(rule)
        db.commit()
        db.refresh(rule)
        print(
            f"[ADD] Global routing rule for 'tester_assigned' created "
            f"(id={rule.id})\n"
            f"      channels : email + inapp\n"
            f"      recipient: @assignee  (→ assigned_tester_id on the request)"
        )

    finally:
        db.close()


if __name__ == "__main__":
    seed()
