"""
add_dashboard_modules.py
========================
One-shot idempotent script — run once on any live database to:

  1. Insert "EE TLSS Dashboard" and "Notifications" into the modules table.
  2. Grant role_module_privileges to all relevant global roles (legacy system).
  3. Grant org_role_permissions to every org role in every organisation
     (new multi-tenancy system) — the dashboard_service already filters widgets
     by OrgRole name, so everyone is allowed in; the service decides what they see.

Safe to re-run: all inserts are guarded by existence checks.

Usage:
  python add_dashboard_modules.py
"""

from dotenv import load_dotenv
load_dotenv()

from database import SessionLocal
from models import Module, Role, RoleModulePrivilege
from sqlalchemy import text
from datetime import datetime, timezone

# ── Module definitions ─────────────────────────────────────────────────────

NEW_MODULES = [
    {
        "name":        "EE TLSS Dashboard",
        "description": "Condition monitoring KPI dashboard — EE TLSS operational view",
        "path":        "ee-dashboard",
        "group_name":  "Testing",
        "is_active":   True,
    },
    {
        "name":        "Notifications",
        "description": "In-app notification centre — alerts, overdue reminders, approvals",
        "path":        "notifications",
        "group_name":  "Testing",
        "is_active":   True,
    },
]

# Global roles that should see these modules in the sidebar drawer
DASHBOARD_ROLES = [
    "Admin", "Viewer", "Auditor",
    "Originator", "Field Tester", "Lab Tester",
    "Test Assigner", "Department Head", "Purchaser",
]

NOTIFICATION_ROLES = [
    "Admin", "Viewer", "Auditor",
    "Originator", "Field Tester", "Lab Tester",
    "Test Assigner", "Department Head", "Purchaser",
    "Vendor",
]


def run():
    db = SessionLocal()
    now = datetime.now(timezone.utc)

    try:
        # ── Step 1: Upsert modules ────────────────────────────────────────
        module_ids = {}
        for m in NEW_MODULES:
            existing = db.query(Module).filter_by(name=m["name"]).first()
            if existing:
                existing.description = m["description"]
                existing.path        = m["path"]
                existing.group_name  = m["group_name"]
                existing.is_active   = m["is_active"]
                module_ids[m["name"]] = existing.id
                print(f"[INFO] Module already exists, updated: {m['name']} (id={existing.id})")
            else:
                mod = Module(
                    name        = m["name"],
                    description = m["description"],
                    path        = m["path"],
                    group_name  = m["group_name"],
                    is_active   = m["is_active"],
                )
                db.add(mod)
                db.flush()
                module_ids[m["name"]] = mod.id
                print(f"[OK]   Created module: {m['name']} (id={mod.id})")

        db.commit()

        # ── Step 2: Grant role_module_privileges (legacy system) ──────────
        role_to_modules = {
            "EE TLSS Dashboard": DASHBOARD_ROLES,
            "Notifications":     NOTIFICATION_ROLES,
        }

        for module_name, allowed_roles in role_to_modules.items():
            module_id = module_ids[module_name]
            for role_name in allowed_roles:
                role = db.query(Role).filter_by(name=role_name).first()
                if not role:
                    print(f"[WARN] Global role not found: {role_name} — skipping")
                    continue

                exists = db.query(RoleModulePrivilege).filter_by(
                    role_id=role.id, module_id=module_id
                ).first()
                if exists:
                    print(f"[INFO] Privilege already exists: {role_name} → {module_name}")
                    continue

                db.add(RoleModulePrivilege(
                    role_id    = role.id,
                    module_id  = module_id,
                    can_view   = True,
                    can_add    = False,
                    can_edit   = False,
                    can_delete = False,
                    can_search = False,
                    can_import = False,
                    can_export = False,
                    can_approve= False,
                    can_assign = False,
                ))
                print(f"[OK]   Granted can_view: {role_name} → {module_name}")

        db.commit()

        # ── Step 3: Grant org_role_permissions (multi-tenancy system) ─────
        # Grant can_view to ALL org roles across ALL organisations.
        # The dashboard_service.py already gates which widgets each role sees —
        # there's no need to restrict at the module-permission level.
        for module_name, module_id in module_ids.items():
            result = db.execute(text("""
                SELECT r.id, r.name, o.name AS org_name
                FROM   org_roles r
                JOIN   organizations o ON o.id = r.organization_id
                WHERE  r.is_active = true
            """)).fetchall()

            for row in result:
                org_role_id = row[0]
                org_role_name = row[1]
                org_name = row[2]

                exists = db.execute(text("""
                    SELECT id FROM org_role_permissions
                    WHERE org_role_id = :rid AND module_id = :mid
                """), {"rid": org_role_id, "mid": module_id}).fetchone()

                if exists:
                    continue  # already granted

                db.execute(text("""
                    INSERT INTO org_role_permissions (
                        id, org_role_id, module_id,
                        can_view, can_add, can_edit, can_delete,
                        can_approve, can_assign, can_export, can_import,
                        cts, mts
                    ) VALUES (
                        gen_random_uuid(), :rid, :mid,
                        true, false, false, false,
                        false, false, false, false,
                        :now, :now
                    )
                """), {"rid": org_role_id, "mid": module_id, "now": now})
                print(f"[OK]   org_role_permissions: [{org_name}] {org_role_name} → {module_name}")

        db.commit()
        print()
        print("=" * 60)
        print("  Done — dashboard modules inserted and permissions granted.")
        print("  Re-run seed.py if you also want new users to get these via")
        print("  the standard seed flow.")
        print("=" * 60)

    except Exception as e:
        db.rollback()
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()


if __name__ == "__main__":
    print()
    print("=" * 60)
    print("  Add Dashboard Modules + Permissions")
    print("=" * 60)
    print()
    run()
