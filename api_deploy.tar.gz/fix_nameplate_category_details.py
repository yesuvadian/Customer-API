#!/usr/bin/env python3
"""Fix nameplate CategoryDetails structure to have one per equipment type."""
from database import get_db
from sqlalchemy import text

db = next(get_db())

print("=" * 80)
print("FIX NAMEPLATE CATEGORY DETAILS")
print("=" * 80)

# Mapping of nameplate template keys to equipment names
NAMEPLATE_EQUIPMENT_MAP = {
    "nameplate_battery_charger": "Battery Charger",
    "nameplate_battery_set": "Battery Set",
    "nameplate_capacitor_voltage_transformer": "Capacitor Voltage Transformer",
    "nameplate_circuit_breaker": "Circuit Breaker",
    "nameplate_control_relay_panel": "Control & Relay Panel",
    "nameplate_current_transformer": "Current Transformer",
    "nameplate_diesel_generator_set": "Diesel Generator Set",
    "nameplate_digital_communication_panel": "Digital Communication Panel",
    "nameplate_electronic_trivector_meter": "Electronic Tri-vector Meter",
    "nameplate_fire_fighting_system": "Fire Fighting System",
    "nameplate_isolator": "Isolator / Disconnector",
    "nameplate_ltac_panel": "LTAC Panel",
    "nameplate_plcc_panel": "PLCC Panel",
    "nameplate_potential_transformer": "Potential Transformer",
    "nameplate_power_transformer": "Power Transformer",
    "nameplate_protection_relay": "Protection Relay",
    "nameplate_station_auxiliary_transformer": "Station Auxiliary Transformer",
    "nameplate_surge_arrestor": "Surge Arrestor",
    "nameplate_wave_trap": "Wave Trap",
}

print(f"\nFound {len(NAMEPLATE_EQUIPMENT_MAP)} nameplate templates to fix\n")

# Step 1: Create "Nameplate" CategoryDetails for each equipment type
print("Step 1: Creating Nameplate CategoryDetails for each equipment type")
print("-" * 80)

created_count = 0
for template_key, equipment_name in NAMEPLATE_EQUIPMENT_MAP.items():
    # Find or create the CategoryMaster for this equipment
    query = 'SELECT id FROM "CategoryMaster" WHERE name = :name'
    master = db.execute(text(query), {"name": equipment_name}).first()

    if not master:
        # Create CategoryMaster if it doesn't exist
        insert_query = 'INSERT INTO "CategoryMaster" (name, description, is_active, cts, mts) VALUES (:name, \'Testing Equipment\', true, NOW(), NOW())'
        db.execute(text(insert_query), {"name": equipment_name})
        master = db.execute(text(query), {"name": equipment_name}).first()
        print(f"[CREATED] CategoryMaster: {equipment_name}")

    master_id = master.id

    # Check if "Nameplate" CategoryDetails already exists for this equipment
    check_query = 'SELECT id FROM "CategoryDetails" WHERE name = \'Nameplate\' AND category_master_id = :master_id'
    existing_detail = db.execute(text(check_query), {"master_id": master_id}).first()

    if not existing_detail:
        # Create the Nameplate CategoryDetails
        insert_detail = 'INSERT INTO "CategoryDetails" (name, description, category_type, category_master_id, is_active, cts, mts) VALUES (\'Nameplate\', :desc, \'nameplate\', :master_id, true, NOW(), NOW())'
        db.execute(text(insert_detail), {
            "desc": f"Nameplate data entry for {equipment_name}",
            "master_id": master_id
        })
        created_count += 1
        print(f"[CREATED] Nameplate CategoryDetails for {equipment_name}")
    else:
        print(f"[EXISTS]  Nameplate CategoryDetails for {equipment_name}")

db.commit()
print(f"\n[OK] Created {created_count} new Nameplate CategoryDetails\n")

# Step 2: Update OrgTestTemplate records to link to correct CategoryDetails
print("Step 2: Relinking nameplate templates to correct CategoryDetails")
print("-" * 80)

updated_count = 0
for template_key, equipment_name in NAMEPLATE_EQUIPMENT_MAP.items():
    # Get the correct CategoryDetails ID for this equipment's nameplate
    get_detail_query = 'SELECT cd.id FROM "CategoryDetails" cd JOIN "CategoryMaster" cm ON cd.category_master_id = cm.id WHERE cd.name = \'Nameplate\' AND cm.name = :equipment_name'
    detail = db.execute(text(get_detail_query), {"equipment_name": equipment_name}).first()

    if not detail:
        print(f"[ERROR] Could not find Nameplate CategoryDetails for {equipment_name}")
        continue

    detail_id = detail.id

    # Update the OrgTestTemplate to use this CategoryDetails
    update_query = 'UPDATE org_test_templates SET test_type_id = :detail_id WHERE template_key = :template_key'
    result = db.execute(text(update_query), {"detail_id": detail_id, "template_key": template_key})

    if result.rowcount > 0:
        updated_count += 1
        print(f"[UPDATED] {template_key:45s} -> {equipment_name}")

db.commit()
print(f"\n[OK] Updated {updated_count} nameplate template links\n")

# Step 3: Verify the fix
print("Step 3: Verification")
print("-" * 80)

verify_query = 'SELECT ott.template_key, ott.template_data->>\'name\' as template_name, cm.name as equipment_master FROM org_test_templates ott LEFT JOIN "CategoryDetails" cd ON ott.test_type_id = cd.id LEFT JOIN "CategoryMaster" cm ON cd.category_master_id = cm.id WHERE ott.template_key LIKE \'nameplate_%\' ORDER BY ott.template_key'
result = db.execute(text(verify_query)).fetchall()

mismatches = 0
for r in result:
    # Extract equipment name from template_key
    expected_equipment = NAMEPLATE_EQUIPMENT_MAP.get(r.template_key, "Unknown")
    if r.equipment_master != expected_equipment:
        print(f"[MISMATCH] {r.template_key}: Expected {expected_equipment}, Got {r.equipment_master}")
        mismatches += 1

if mismatches == 0:
    print(f"[OK] All {len(result)} nameplate templates correctly linked!")
else:
    print(f"[WARN] {mismatches} mismatches found")

db.close()

print("\n" + "=" * 80)
print("[DONE] Nameplate CategoryDetails fix completed!")
print("=" * 80)
