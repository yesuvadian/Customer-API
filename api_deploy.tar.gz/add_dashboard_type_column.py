"""
Add default_dashboard_type column to org_roles and role_templates tables.

Dashboard types:
- admin: Full admin dashboard (financial + testing overview)
- supervisor: Approval/supervisory dashboard (KPIs, approvals, reports)
- field: Field worker dashboard (assignments, testing)
- generic: Generic welcome screen (minimal/no data)
"""

from database import SessionLocal, engine
from sqlalchemy import text

def add_dashboard_type_columns():
    db = SessionLocal()
    try:
        print("[INFO] Adding default_dashboard_type column to org_roles table...")

        # Add column to org_roles
        db.execute(text("""
            ALTER TABLE public.org_roles
            ADD COLUMN IF NOT EXISTS default_dashboard_type VARCHAR(50) DEFAULT 'generic';
        """))

        print("[INFO] Adding default_dashboard_type column to role_templates table...")

        # Add column to role_templates
        db.execute(text("""
            ALTER TABLE public.role_templates
            ADD COLUMN IF NOT EXISTS default_dashboard_type VARCHAR(50) DEFAULT 'generic';
        """))

        db.commit()
        print("[OK] Columns added successfully")

        # Update existing role templates with appropriate dashboard types
        print("[INFO] Setting dashboard types for role templates...")

        updates = [
            ("Admin", "admin"),
            ("Org Admin", "admin"),
            ("Originator", "field"),
            ("Test Assigner", "supervisor"),
            ("Field Tester", "field"),
            ("Lab Tester", "field"),
            ("Department Head", "supervisor"),
            ("Purchaser", "field"),
            ("doc-viewer", "generic"),
            # SRS designation roles
            ("AEE Maintenance", "supervisor"),
            ("EE TLSS", "supervisor"),
            ("SEE W&M", "supervisor"),
            ("EE RT", "supervisor"),
            ("SEE RT", "supervisor"),
            ("CEE Transmission Zone", "supervisor"),
            ("CEE RT&R&D", "supervisor"),
        ]

        for role_name, dashboard_type in updates:
            db.execute(text("""
                UPDATE public.role_templates
                SET default_dashboard_type = :dashboard_type
                WHERE name = :role_name
            """), {"dashboard_type": dashboard_type, "role_name": role_name})

        db.commit()
        print(f"[OK] Updated {len(updates)} role templates with dashboard types")

        # Update existing org_roles based on their name match
        print("[INFO] Updating existing org_roles with dashboard types...")

        for role_name, dashboard_type in updates:
            result = db.execute(text("""
                UPDATE public.org_roles
                SET default_dashboard_type = :dashboard_type
                WHERE name = :role_name
            """), {"dashboard_type": dashboard_type, "role_name": role_name})
            if result.rowcount > 0:
                print(f"  [+] Updated {result.rowcount} org_roles for '{role_name}' -> {dashboard_type}")

        db.commit()
        print("[OK] Org roles updated successfully")

        print("\n" + "="*80)
        print("Dashboard Type Migration Complete!")
        print("="*80)
        print("\nDashboard types configured:")
        print("  - admin: Admin, Org Admin")
        print("  - supervisor: All SRS roles (AEE, EE, SEE, CEE), Test Assigner, Department Head")
        print("  - field: Originator, Testers, Purchaser")
        print("  - generic: doc-viewer, unknown roles")

    except Exception as e:
        db.rollback()
        print(f"[ERROR] Migration failed: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    add_dashboard_type_columns()
