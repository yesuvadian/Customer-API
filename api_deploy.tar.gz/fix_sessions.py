"""
Fix TR-20260421-0005 sessions and link existing test result
"""
import psycopg2

DB_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'database': 'Relu_Vendor2',
    'user': 'relu_user',
    'password': 'StrongPassword123!'
}

def fix_sessions():
    """Fix the sessions and link test result"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cursor = conn.cursor()

        print("=" * 70)
        print("FIXING TR-20260421-0005")
        print("=" * 70)

        # Get request ID
        cursor.execute("""
            SELECT id FROM public.testing_requests
            WHERE request_number = 'TR-20260421-0005'
        """)
        request_id = cursor.fetchone()[0]
        print(f"\nRequest ID: {request_id}")

        # Get sessions
        cursor.execute("""
            SELECT id, session_number, status
            FROM public.test_sessions
            WHERE testing_request_id = %s
            ORDER BY session_number
        """, (request_id,))
        sessions = cursor.fetchall()

        print(f"\nFound {len(sessions)} sessions")

        if len(sessions) >= 1:
            # Keep Session 1 as in_progress
            session1_id = sessions[0][0]
            print(f"\nSession 1 ID: {session1_id}")

            cursor.execute("""
                UPDATE public.test_sessions
                SET status = 'in_progress'
                WHERE id = %s
            """, (session1_id,))
            print(f"[OK] Session 1 -> status = 'in_progress'")

            # Link existing test result to Session 1
            cursor.execute("""
                UPDATE public.test_results
                SET test_session_id = %s
                WHERE testing_request_id = %s
                AND test_session_id IS NULL
            """, (session1_id, request_id))
            linked_count = cursor.rowcount
            print(f"[OK] Linked {linked_count} test result(s) to Session 1")

        if len(sessions) >= 2:
            # Delete Session 2 (it's empty and was created by mistake)
            session2_id = sessions[1][0]
            cursor.execute("""
                DELETE FROM public.test_sessions
                WHERE id = %s
            """, (session2_id,))
            print(f"[OK] Deleted Session 2 (empty duplicate)")

        conn.commit()

        # Verify
        print("\n" + "=" * 70)
        print("VERIFICATION")
        print("=" * 70)

        cursor.execute("""
            SELECT session_number, status
            FROM public.test_sessions
            WHERE testing_request_id = %s
            ORDER BY session_number
        """, (request_id,))
        sessions_after = cursor.fetchall()

        print(f"\nSessions after fix:")
        for sess in sessions_after:
            print(f"  Session {sess[0]}: {sess[1]}")

        cursor.execute("""
            SELECT COUNT(*), test_session_id
            FROM public.test_results
            WHERE testing_request_id = %s
            GROUP BY test_session_id
        """, (request_id,))
        results_after = cursor.fetchall()

        print(f"\nTest results after fix:")
        for count, sess_id in results_after:
            print(f"  {count} result(s) linked to session: {sess_id}")

        cursor.close()
        conn.close()

        print("\n" + "=" * 70)
        print("[SUCCESS] FIX COMPLETE!")
        print("=" * 70)
        print("\nNext steps:")
        print("1. Refresh the Flutter app")
        print("2. Session 1 should show 1 reading (CT Ratio Test)")
        print("3. Click on the reading to view entered data")

    except Exception as e:
        print(f"\n[ERROR] {e}")
        if conn:
            conn.rollback()

if __name__ == "__main__":
    fix_sessions()
