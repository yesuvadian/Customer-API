"""
Add can_assign permission to SEE W&M role for Testing Request Approvals module
SEE W&M is the SRS-designated equivalent to Test Assigner role
"""
from database import SessionLocal
from models import OrgRole, OrgRolePermission, Module, Organization

db = SessionLocal()

try:
    print("=" * 80)
    print("ADDING can_assign PERMISSION TO SEE W&M ROLE")
    print("=" * 80)

    # Get KPTCL org
    kptcl = db.query(Organization).filter(Organization.name.like('%Karnataka%')).first()

    if not kptcl:
        print("[ERROR] KPTCL organization not found")
        exit(1)

    print(f"[OK] Found organization: {kptcl.name}")

    # Get Testing Request Approvals module
    module = db.query(Module).filter(Module.name == 'Testing Request Approvals').first()

    if not module:
        print("[ERROR] Testing Request Approvals module not found")
        exit(1)

    print(f"[OK] Found module: {module.name} (id: {module.id})")

    # Get SEE W&M role
    see_wm_role = db.query(OrgRole).filter(
        OrgRole.organization_id == kptcl.id,
        OrgRole.name == 'SEE W&M',
        OrgRole.is_active == True
    ).first()

    if not see_wm_role:
        print("[ERROR] SEE W&M role not found")
        exit(1)

    print(f"[OK] Found role: {see_wm_role.name} (id: {see_wm_role.id})")

    # Find and update the permission
    perm = db.query(OrgRolePermission).filter(
        OrgRolePermission.org_role_id == see_wm_role.id,
        OrgRolePermission.module_id == module.id
    ).first()

    if perm:
        print(f"\n[INFO] Current permissions:")
        print(f"  can_view: {perm.can_view}")
        print(f"  can_approve: {perm.can_approve}")
        print(f"  can_assign: {perm.can_assign}")

        if not perm.can_assign:
            perm.can_assign = True
            db.commit()
            print(f"\n[OK] Added can_assign permission to SEE W&M")
        else:
            print(f"\n[INFO] SEE W&M already has can_assign permission")
    else:
        print(f"\n[INFO] No existing permission found, creating new one...")
        new_perm = OrgRolePermission(
            org_role_id=see_wm_role.id,
            module_id=module.id,
            can_view=True,
            can_approve=True,
            can_assign=True
        )
        db.add(new_perm)
        db.commit()
        print(f"[OK] Created Testing Request Approvals permission for SEE W&M with can_assign=True")

    print("\n" + "=" * 80)
    print("SUCCESS: SEE W&M now has full Test Assigner permissions")
    print("SEE W&M can now approve testing requests AND assign testers")
    print("=" * 80)

except Exception as e:
    print(f"\nERROR: {e}")
    db.rollback()
    raise
finally:
    db.close()
