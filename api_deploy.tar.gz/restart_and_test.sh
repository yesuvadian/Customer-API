#!/bin/bash

# Configuration
PORT=${1:-8005}
BASE_DIR="C:\Yesu\CustomerAPI\Customer-API"

echo "=========================================="
echo "Restarting API on port $PORT"
echo "=========================================="

# 1. Kill any existing Python processes on the port
echo "Step 1: Killing processes on port $PORT..."
PID=$(netstat -ano | grep ":$PORT " | grep "LISTENING" | awk '{print $5}' | head -1)
if [ ! -z "$PID" ]; then
    echo "  Found process $PID on port $PORT, killing..."
    powershell -Command "Stop-Process -Id $PID -Force -ErrorAction SilentlyContinue" 2>/dev/null || true
    sleep 2
fi

# 2. Kill any remaining Python processes
echo "Step 2: Killing all Python processes..."
powershell -Command "Get-Process python* -ErrorAction SilentlyContinue | Stop-Process -Force" 2>/dev/null || true
sleep 2

# 3. Clear Python cache
echo "Step 3: Clearing Python cache..."
find "$BASE_DIR" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "$BASE_DIR" -type f -name "*.pyc" -delete 2>/dev/null || true

# 4. Verify port is free
echo "Step 4: Verifying port $PORT is free..."
sleep 1
if netstat -ano | grep ":$PORT " | grep "LISTENING" > /dev/null; then
    echo "  ERROR: Port $PORT is still in use!"
    netstat -ano | grep ":$PORT "
    exit 1
fi
echo "  Port $PORT is free"

# 5. Update test script to use new port
echo "Step 5: Updating test script to use port $PORT..."
sed -i "s/BASE_URL = \"http:\/\/localhost:[0-9]*\"/BASE_URL = \"http:\/\/localhost:$PORT\"/" "$BASE_DIR/test_approval_only.py"
sed -i "s/BASE_URL = \"http:\/\/localhost:[0-9]*\"/BASE_URL = \"http:\/\/localhost:$PORT\"/" "$BASE_DIR/test_full_cycle.py"

# 6. Start server
echo "Step 6: Starting server on port $PORT..."
cd "$BASE_DIR"
powershell -Command "Start-Process python -ArgumentList '-m','uvicorn','main:app','--reload','--host','0.0.0.0','--port','$PORT' -WindowStyle Hidden"

# 7. Wait for server to start
echo "Step 7: Waiting for server to start..."
for i in {1..15}; do
    sleep 1
    if netstat -ano | grep ":$PORT " | grep "LISTENING" > /dev/null; then
        echo "  Server is up!"
        break
    fi
    echo "  Waiting... ($i/15)"
done

# 8. Verify server is running
if ! netstat -ano | grep ":$PORT " | grep "LISTENING" > /dev/null; then
    echo "  ERROR: Server failed to start on port $PORT"
    exit 1
fi

# 9. Run test
echo ""
echo "=========================================="
echo "Running test: $TEST_SCRIPT"
echo "=========================================="
python "$BASE_DIR/${TEST_SCRIPT:-test_approval_only.py}"

echo ""
echo "=========================================="
echo "Done!"
echo "=========================================="
