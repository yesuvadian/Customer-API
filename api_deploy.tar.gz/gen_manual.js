/**
 * SEACMS User Manual Generator
 * Covers: Multi-Session Testing, Failure Registry, TA&QC Inspection, Approvals
 */
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
  ShadingType, VerticalAlign, PageNumber, PageBreak, LevelFormat,
  TableOfContents
} = require('docx');
const fs = require('fs');

// ── Color palette ────────────────────────────────────────────────────────────
const BLUE_DARK  = "1b3a6b";
const BLUE_MID   = "2E75B6";
const BLUE_LIGHT = "D5E8F0";
const BLUE_PALE  = "EBF3FB";
const GRAY_LIGHT = "F5F5F5";
const GRAY_MID   = "CCCCCC";
const GREEN      = "1a7340";
const GREEN_BG   = "E8F5E9";
const ORANGE     = "c75b00";
const ORANGE_BG  = "FFF3E0";
const RED        = "b71c1c";
const RED_BG     = "FFEBEE";
const WHITE      = "FFFFFF";
const BLACK      = "000000";

// ── Helpers ──────────────────────────────────────────────────────────────────
const mkborder = function(color) { color = color || GRAY_MID; return { style: BorderStyle.SINGLE, size: 1, color: color }; };
const mkborders = function(color) { var b = mkborder(color); return { top: b, bottom: b, left: b, right: b }; };

function hr() {
  return new Paragraph({
    spacing: { before: 120, after: 120 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: BLUE_MID, space: 1 } },
    children: [],
  });
}

function spacer(before, after) {
  before = before !== undefined ? before : 160;
  after = after !== undefined ? after : 0;
  return new Paragraph({ spacing: { before: before, after: after }, children: [] });
}

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160 },
    children: [new TextRun({ text: text, font: "Arial", size: 32, bold: true, color: BLUE_DARK })],
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
    children: [new TextRun({ text: text, font: "Arial", size: 26, bold: true, color: BLUE_MID })],
  });
}

function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 200, after: 80 },
    children: [new TextRun({ text: text, font: "Arial", size: 22, bold: true, color: BLUE_DARK })],
  });
}

function para(text, opts) {
  opts = opts || {};
  return new Paragraph({
    spacing: { before: opts.before !== undefined ? opts.before : 80, after: opts.after !== undefined ? opts.after : 80 },
    children: [new TextRun({ text: text, font: "Arial", size: opts.size || 22, color: opts.color || BLACK, bold: opts.bold || false, italics: opts.italic || false })],
  });
}

function bullet(text, level) {
  level = level !== undefined ? level : 0;
  return new Paragraph({
    numbering: { reference: "bullets", level: level },
    spacing: { before: 60, after: 60 },
    children: [new TextRun({ text: text, font: "Arial", size: 22, color: BLACK })],
  });
}

function stepBold(label, rest) {
  rest = rest || "";
  return new Paragraph({
    numbering: { reference: "steps", level: 0 },
    spacing: { before: 80, after: 80 },
    children: [
      new TextRun({ text: label, font: "Arial", size: 22, bold: true, color: BLUE_DARK }),
      new TextRun({ text: rest, font: "Arial", size: 22, color: BLACK }),
    ],
  });
}

function noteBox(text, type) {
  type = type || "note";
  var colors = {
    note:      { bg: BLUE_PALE,  label: "NOTE",      labelColor: BLUE_DARK },
    tip:       { bg: GREEN_BG,   label: "TIP",       labelColor: GREEN },
    warning:   { bg: ORANGE_BG,  label: "WARNING",   labelColor: ORANGE },
    important: { bg: RED_BG,     label: "IMPORTANT", labelColor: RED },
  };
  var c = colors[type] || colors.note;
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [new TableRow({ children: [
      new TableCell({
        borders: mkborders(BLUE_LIGHT),
        width: { size: 9360, type: WidthType.DXA },
        shading: { fill: c.bg, type: ShadingType.CLEAR },
        margins: { top: 100, bottom: 100, left: 180, right: 180 },
        children: [new Paragraph({
          children: [
            new TextRun({ text: c.label + ": ", font: "Arial", size: 20, bold: true, color: c.labelColor }),
            new TextRun({ text: text, font: "Arial", size: 20, color: BLACK }),
          ],
        })],
      }),
    ]})]
  });
}

function workflowTable(steps) {
  var hdr = new TableRow({ tableHeader: true, children: [
    new TableCell({ borders: mkborders(BLUE_DARK), width: { size: 500, type: WidthType.DXA },
      shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 80, right: 80 },
      children: [new Paragraph({ children: [new TextRun({ text: "#", font: "Arial", size: 18, bold: true, color: WHITE })] })] }),
    new TableCell({ borders: mkborders(BLUE_DARK), width: { size: 2200, type: WidthType.DXA },
      shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: "Status", font: "Arial", size: 18, bold: true, color: WHITE })] })] }),
    new TableCell({ borders: mkborders(BLUE_DARK), width: { size: 2100, type: WidthType.DXA },
      shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: "Performed By", font: "Arial", size: 18, bold: true, color: WHITE })] })] }),
    new TableCell({ borders: mkborders(BLUE_DARK), width: { size: 4560, type: WidthType.DXA },
      shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: "Action", font: "Arial", size: 18, bold: true, color: WHITE })] })] }),
  ]});
  var rows = steps.map(function(s, i) {
    return new TableRow({ children: [
      new TableCell({
        borders: mkborders(GRAY_MID), width: { size: 500, type: WidthType.DXA },
        shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 80, right: 80 },
        verticalAlign: VerticalAlign.CENTER,
        children: [new Paragraph({ alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: String(s.num), font: "Arial", size: 22, bold: true, color: WHITE })] })],
      }),
      new TableCell({
        borders: mkborders(GRAY_MID), width: { size: 2200, type: WidthType.DXA },
        shading: { fill: s.bg, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
        verticalAlign: VerticalAlign.CENTER,
        children: [new Paragraph({ alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: s.status, font: "Arial", size: 20, bold: true, color: s.color })] })],
      }),
      new TableCell({
        borders: mkborders(GRAY_MID), width: { size: 2100, type: WidthType.DXA },
        shading: { fill: i % 2 === 0 ? GRAY_LIGHT : WHITE, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: s.actor, font: "Arial", size: 20, bold: true, color: BLUE_MID })] })],
      }),
      new TableCell({
        borders: mkborders(GRAY_MID), width: { size: 4560, type: WidthType.DXA },
        shading: { fill: i % 2 === 0 ? GRAY_LIGHT : WHITE, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: s.desc, font: "Arial", size: 20, color: BLACK })] })],
      }),
    ]});
  });
  return new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: [500, 2200, 2100, 4560], rows: [hdr].concat(rows) });
}

function roleTable(rows) {
  var headerRow = new TableRow({ tableHeader: true, children: [
    new TableCell({ borders: mkborders(BLUE_MID), width: { size: 2600, type: WidthType.DXA },
      shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: "Role", font: "Arial", size: 20, bold: true, color: WHITE })] })] }),
    new TableCell({ borders: mkborders(BLUE_MID), width: { size: 3560, type: WidthType.DXA },
      shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: "Key Permissions", font: "Arial", size: 20, bold: true, color: WHITE })] })] }),
    new TableCell({ borders: mkborders(BLUE_MID), width: { size: 3200, type: WidthType.DXA },
      shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: "Typical Login", font: "Arial", size: 20, bold: true, color: WHITE })] })] }),
  ]});
  var dataRows = rows.map(function(r, i) {
    return new TableRow({ children: [
      new TableCell({ borders: mkborders(GRAY_MID), width: { size: 2600, type: WidthType.DXA },
        shading: { fill: i % 2 === 0 ? BLUE_PALE : WHITE, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: r[0], font: "Arial", size: 20, bold: true, color: BLUE_DARK })] })] }),
      new TableCell({ borders: mkborders(GRAY_MID), width: { size: 3560, type: WidthType.DXA },
        shading: { fill: i % 2 === 0 ? BLUE_PALE : WHITE, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: r[1], font: "Arial", size: 20, color: BLACK })] })] }),
      new TableCell({ borders: mkborders(GRAY_MID), width: { size: 3200, type: WidthType.DXA },
        shading: { fill: i % 2 === 0 ? BLUE_PALE : WHITE, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: r[2], font: "Arial", size: 20, italics: true, color: ORANGE })] })] }),
    ]});
  });
  return new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: [2600, 3560, 3200], rows: [headerRow].concat(dataRows) });
}

function twoColTable(colW1, colW2, headers, dataRows, issueStyle) {
  var hw = [colW1, colW2];
  var hdr = new TableRow({ tableHeader: true, children: headers.map(function(h, i) {
    return new TableCell({ borders: mkborders(BLUE_DARK), width: { size: hw[i], type: WidthType.DXA },
      shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: h, font: "Arial", size: 20, bold: true, color: WHITE })] })] });
  })});
  var drs = dataRows.map(function(row, i) {
    return new TableRow({ children: row.map(function(cell, j) {
      var isIssue = issueStyle && j === 0;
      return new TableCell({ borders: mkborders(GRAY_MID), width: { size: hw[j], type: WidthType.DXA },
        shading: { fill: i % 2 === 0 ? (isIssue ? ORANGE_BG : GRAY_LIGHT) : WHITE, type: ShadingType.CLEAR }, margins: { top: 100, bottom: 100, left: 120, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: cell, font: "Arial", size: 20, bold: isIssue, color: isIssue ? RED : BLACK })] })] });
    })});
  });
  return new Table({ width: { size: colW1 + colW2, type: WidthType.DXA }, columnWidths: [colW1, colW2], rows: [hdr].concat(drs) });
}

// ── Build document ────────────────────────────────────────────────────────────
var doc = new Document({
  numbering: {
    config: [
      { reference: "bullets",
        levels: [
          { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } } },
          { level: 1, format: LevelFormat.BULLET, text: "◦", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 1080, hanging: 360 } } } },
        ] },
      { reference: "steps",
        levels: [
          { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } } },
          { level: 1, format: LevelFormat.DECIMAL, text: "%2.", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 1080, hanging: 360 } } } },
        ] },
    ],
  },
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: "Arial", color: BLUE_DARK },
        paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: "Arial", color: BLUE_MID },
        paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, font: "Arial", color: BLUE_DARK },
        paragraph: { spacing: { before: 200, after: 80 }, outlineLevel: 2 } },
    ],
  },
  sections: [{
    properties: {
      page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1260, bottom: 1440, left: 1260 } },
    },
    headers: {
      default: new Header({ children: [new Paragraph({
        border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: BLUE_MID, space: 1 } },
        tabStops: [{ type: "right", position: 9360 }],
        children: [
          new TextRun({ text: "SEACMS — SubStation Equipment & Asset Condition Monitoring System", font: "Arial", size: 18, color: BLUE_DARK }),
          new TextRun({ text: "\t", font: "Arial", size: 18 }),
          new TextRun({ text: "User Manual | KPTCL", font: "Arial", size: 18, italics: true, color: BLUE_MID }),
        ],
      })] }),
    },
    footers: {
      default: new Footer({ children: [new Paragraph({
        border: { top: { style: BorderStyle.SINGLE, size: 4, color: BLUE_MID, space: 1 } },
        tabStops: [{ type: "right", position: 9360 }],
        children: [
          new TextRun({ text: "KPTCL Internal Use Only", font: "Arial", size: 18, color: GRAY_MID }),
          new TextRun({ text: "\t", font: "Arial", size: 18 }),
          new TextRun({ text: "Page ", font: "Arial", size: 18, color: BLUE_DARK }),
          new TextRun({ children: [PageNumber.CURRENT], font: "Arial", size: 18, color: BLUE_DARK }),
        ],
      })] }),
    },
    children: [
      // ──────────────────────────────────────────────────────────────────────
      // COVER PAGE
      // ──────────────────────────────────────────────────────────────────────
      spacer(1200),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 120 },
        children: [new TextRun({ text: "SEACMS", font: "Arial", size: 72, bold: true, color: BLUE_DARK })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 240 },
        children: [new TextRun({ text: "SubStation Equipment & Asset Condition Monitoring System", font: "Arial", size: 28, color: BLUE_MID })] }),
      hr(),
      spacer(160),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 80 },
        children: [new TextRun({ text: "User Manual", font: "Arial", size: 48, bold: true, color: BLUE_DARK })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 320 },
        children: [new TextRun({ text: "Multi-Session Testing  |  Failure Registry  |  TA&QC Inspection  |  Approvals", font: "Arial", size: 24, italics: true, color: BLUE_MID })] }),
      new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: [4680, 4680],
        rows: [
          new TableRow({ children: [
            new TableCell({ borders: mkborders(BLUE_LIGHT), width: { size: 4680, type: WidthType.DXA },
              shading: { fill: BLUE_PALE, type: ShadingType.CLEAR }, margins: { top: 120, bottom: 120, left: 200, right: 200 },
              children: [
                new Paragraph({ children: [new TextRun({ text: "Organisation", font: "Arial", size: 18, bold: true, color: BLUE_MID })] }),
                new Paragraph({ children: [new TextRun({ text: "Karnataka Power Transmission Corporation Limited (KPTCL)", font: "Arial", size: 20, color: BLACK })] }),
              ] }),
            new TableCell({ borders: mkborders(BLUE_LIGHT), width: { size: 4680, type: WidthType.DXA },
              shading: { fill: BLUE_PALE, type: ShadingType.CLEAR }, margins: { top: 120, bottom: 120, left: 200, right: 200 },
              children: [
                new Paragraph({ children: [new TextRun({ text: "Document Version", font: "Arial", size: 18, bold: true, color: BLUE_MID })] }),
                new Paragraph({ children: [new TextRun({ text: "1.0  —  April 2026", font: "Arial", size: 20, color: BLACK })] }),
              ] }),
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: mkborders(BLUE_LIGHT), width: { size: 4680, type: WidthType.DXA },
              shading: { fill: WHITE, type: ShadingType.CLEAR }, margins: { top: 120, bottom: 120, left: 200, right: 200 },
              children: [
                new Paragraph({ children: [new TextRun({ text: "Module Scope", font: "Arial", size: 18, bold: true, color: BLUE_MID })] }),
                new Paragraph({ children: [new TextRun({ text: "Testing Requests, Sessions, Direct Submissions, Approvals, Reports", font: "Arial", size: 20, color: BLACK })] }),
              ] }),
            new TableCell({ borders: mkborders(BLUE_LIGHT), width: { size: 4680, type: WidthType.DXA },
              shading: { fill: WHITE, type: ShadingType.CLEAR }, margins: { top: 120, bottom: 120, left: 200, right: 200 },
              children: [
                new Paragraph({ children: [new TextRun({ text: "Classification", font: "Arial", size: 18, bold: true, color: BLUE_MID })] }),
                new Paragraph({ children: [new TextRun({ text: "KPTCL Internal Use Only", font: "Arial", size: 20, color: RED })] }),
              ] }),
          ]}),
        ],
      }),
      spacer(400),
      new Paragraph({ children: [new PageBreak()] }),

      // TABLE OF CONTENTS
      new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
      new Paragraph({ children: [new PageBreak()] }),

      // ──────────────────────────────────────────────────────────────────────
      // 1. INTRODUCTION
      // ──────────────────────────────────────────────────────────────────────
      h1("1. Introduction"),
      para("SEACMS (SubStation Equipment & Asset Condition Monitoring System) is KPTCL's integrated platform for managing the full lifecycle of substation equipment testing — from raising a request through tester assignment, field measurement sessions, result submission, and final approval."),
      spacer(80),
      para("This manual is written for KPTCL field and office staff who use the SEACMS web application. It covers three primary workflows:"),
      bullet("Standard Multi-Session Testing — raise a request, assign a tester, conduct one or more measurement sessions, submit results, and seek approval."),
      bullet("Failure Registry (FR) — field staff directly records an equipment failure without a prior assignment step."),
      bullet("TA&QC Inspection (TQ) — TA&QC officers directly log inspection observations for management review."),
      spacer(80),
      noteBox("All content in this manual reflects the SEACMS web application. The mobile companion app follows the same workflow logic with a touch-optimised layout.", "note"),
      spacer(120),

      h2("1.1  System Overview"),
      para("SEACMS is accessible via any modern web browser. No software installation is required on your workstation. Key capabilities:"),
      bullet("Role-based access — each user sees only the screens and actions permitted for their role."),
      bullet("Real-time status tracking — request status updates the moment any action is taken."),
      bullet("Multi-session readings — a single test request can span multiple site visit sessions."),
      bullet("Full audit trail — every action is time-stamped and attributed to a named user."),
      bullet("PDF reports — professional test result PDFs with SPAN-format reading tables, generated on demand."),
      spacer(120),

      // ──────────────────────────────────────────────────────────────────────
      // 2. USER ROLES
      // ──────────────────────────────────────────────────────────────────────
      h1("2. User Roles & Access"),
      para("Every KPTCL user is assigned one or more organisational roles that determine which menus, buttons, and data are visible. The table below lists the roles relevant to the testing modules."),
      spacer(80),
      roleTable([
        ["Originator",       "Raise new testing requests, view own requests",                                  "originator@kptcl.com"],
        ["Field Tester",     "Accept assignments, conduct sessions, record readings, submit results",          "fieldtester1@kptcl.com"],
        ["Lab Tester",       "Same as Field Tester but for in-lab equipment",                                  "labtester1@kptcl.com"],
        ["Test Assigner",    "Assign testers to requests, monitor the queue",                                  "assigner@kptcl.com"],
        ["AEE Maintenance",  "Create Failure Registry records, view reports, submit TA&QC",                   "aee.maintenance@kptcl.com"],
        ["EE TLSS",          "Approve/reject test results, manage departments, submit direct records",        "ee.tlss@kptcl.com"],
        ["TA&QC Officer",    "Create TA&QC Inspection records, review compliance",                            "taqc.officer@kptcl.com"],
        ["Department Head",  "Approve results, view all department activity, create direct records",          "dept.head@kptcl.com"],
        ["Org Admin",        "Full access — manage users, roles, templates, view all requests",          "orgadmin@kptcl.com"],
      ]),
      spacer(120),
      noteBox("Your role is shown in the top-right corner of the application after login. Contact your system administrator if your role appears incorrect.", "note"),
      spacer(80),

      h2("2.1  Logging In"),
      stepBold("Open your browser ", "and navigate to the SEACMS URL provided by your administrator."),
      stepBold("Enter your email address ", "— your official KPTCL email (e.g. fieldtester1@kptcl.com)."),
      stepBold("Enter your password ", "and click Log In."),
      stepBold("On successful login ", "the Dashboard is displayed showing your pending tasks and recent activity."),
      spacer(80),
      noteBox("After five consecutive incorrect password attempts your account is locked for 15 minutes. Contact your administrator if you are locked out.", "warning"),
      spacer(120),

      // ──────────────────────────────────────────────────────────────────────
      // 3. STANDARD MULTI-SESSION WORKFLOW
      // ──────────────────────────────────────────────────────────────────────
      h1("3. Standard Multi-Session Testing Workflow"),
      para("The standard workflow moves a testing request through eight stages, each performed by a different role."),
      spacer(80),
      workflowTable([
        { num: 1, status: "Draft",           color: BLUE_MID,  bg: BLUE_PALE,  actor: "Originator",     desc: "Originator raises a new testing request with equipment details and test type." },
        { num: 2, status: "Submitted",       color: ORANGE,    bg: ORANGE_BG,  actor: "Originator",     desc: "Request is submitted for assignment review by the Test Assigner." },
        { num: 3, status: "Assigned",        color: BLUE_DARK, bg: BLUE_PALE,  actor: "Test Assigner",  desc: "Assigner selects a tester and sets a target date. Tester is notified." },
        { num: 4, status: "Accepted",        color: GREEN,     bg: GREEN_BG,   actor: "Tester",         desc: "Tester confirms they will carry out the test." },
        { num: 5, status: "In Progress",     color: ORANGE,    bg: ORANGE_BG,  actor: "Tester",         desc: "Tester starts the first session. Additional sessions can be added as needed." },
        { num: 6, status: "Test Submitted",  color: BLUE_MID,  bg: BLUE_PALE,  actor: "Tester",         desc: "Tester submits compiled readings and the overall pass/fail/advisory result." },
        { num: 7, status: "Under Approval",  color: ORANGE,    bg: ORANGE_BG,  actor: "Approver",       desc: "Approver (EE TLSS / Department Head) reviews the result and recommendation." },
        { num: 8, status: "Completed",       color: GREEN,     bg: GREEN_BG,   actor: "Approver",       desc: "Approver approves. Request is closed and a PDF certificate is available." },
      ]),
      spacer(120),

      h2("3.1  Raising a New Testing Request (Originator)"),
      para("An Originator creates a new request whenever equipment needs to be tested — routine inspection, fault investigation, or post-maintenance verification."),
      spacer(80),
      stepBold("Navigate to Testing Requests ", "in the left navigation menu."),
      stepBold("Click 'New Request' ", "in the top-right corner of the list screen."),
      stepBold("Fill in the request form:"),
      bullet("Title — a short descriptive name (e.g. 'Transformer T3 — oil BDV test')."),
      bullet("Equipment — search by UEIC code or equipment name and select from the dropdown."),
      bullet("Test Category — select the appropriate category (Routine, Special, Commissioning, etc.)."),
      bullet("Priority — Normal, High, or Urgent."),
      bullet("Department — auto-filled from your profile; change if submitting on behalf of another section."),
      bullet("Notes / Description — optional additional context for the tester."),
      stepBold("Click 'Save as Draft' ", "to store without submitting, or 'Submit' to send directly to the assignment queue."),
      spacer(80),
      noteBox("You can edit a Draft request at any time. Once Submitted, editing is locked until the Assigner returns it.", "note"),
      spacer(120),

      h2("3.2  Assigning a Tester (Test Assigner)"),
      stepBold("Navigate to Testing Requests ", "and filter by Status = Submitted."),
      stepBold("Click on a request ", "to open its detail view."),
      stepBold("Click 'Assign Tester'."),
      stepBold("In the assignment panel:"),
      bullet("Select the Tester from the user list (Field Testers and Lab Testers for KPTCL)."),
      bullet("Set the Target Date — expected date for test completion."),
      bullet("Add any assignment notes for the tester."),
      stepBold("Click 'Confirm Assignment'. ", "Status changes to Assigned and the tester is notified."),
      spacer(120),

      h2("3.3  Accepting an Assignment (Tester)"),
      stepBold("Navigate to 'My Assignments' ", "on your dashboard."),
      stepBold("Locate the newly assigned request ", "(status = Assigned)."),
      stepBold("Click 'Accept Assignment'. ", "Status changes to Accepted."),
      stepBold("(Optional) Add an acceptance note ", "confirming your planned visit date."),
      spacer(80),
      noteBox("If you cannot carry out the assignment, click 'Decline' with a reason. The request returns to the Assigner for re-allocation.", "warning"),
      spacer(120),

      h2("3.4  Creating & Conducting a Test Session (Tester)"),
      para("A Test Session represents a single site visit or measurement run. One testing request can have multiple sessions — useful when equipment needs to be tested under different load conditions or on separate days."),
      spacer(80),
      h3("3.4.1  Starting the First Session"),
      stepBold("Open the Accepted request ", "from My Assignments."),
      stepBold("Click 'Start Testing'. ", "Status changes to In Progress and Session 1 is created automatically."),
      stepBold("In the session detail panel, fill in:"),
      bullet("Session Name — e.g. 'Initial readings 07:00 hrs'."),
      bullet("Planned Date — date of this measurement run."),
      bullet("Notes — weather, load conditions, instrument serial numbers, etc."),
      stepBold("Click 'Begin Session'. ", "Session status changes to In Progress."),
      spacer(80),

      h3("3.4.2  Adding More Sessions (Multiple Visits)"),
      stepBold("From the request detail, ", "scroll to the Sessions panel."),
      stepBold("Click 'Add New Session'. ", "A new session card appears with an auto-incremented session number."),
      stepBold("Fill in session details ", "and click 'Begin Session'."),
      spacer(80),
      noteBox("Sessions are independent. You can have one session In Progress while reviewing readings from a completed session.", "tip"),
      spacer(80),

      h3("3.4.3  Recording Readings within a Session"),
      stepBold("Open the active session ", "and click 'Add Reading'."),
      stepBold("Fill in the measurement parameters ", "— fields vary by test template (e.g. BDV test shows voltage and breakdown values; insulation resistance test shows resistance, temperature, and humidity)."),
      stepBold("Each reading captures:"),
      bullet("Reading Number — auto-assigned."),
      bullet("Reading Time — time the measurement was taken."),
      bullet("Measurement Fields — template-specific values."),
      bullet("Pass / Fail — whether this individual reading met acceptance criteria."),
      bullet("Remarks — any observations for this specific reading."),
      stepBold("Click 'Save Reading'. ", "Repeat for all measurements in this session."),
      stepBold("Once all readings are complete, ", "click 'Complete Session'. Session status changes to Completed."),
      spacer(80),
      noteBox("Click 'Preview' on a completed session to open the session HTML report — a read-only formatted table of all readings with colour-coded pass/fail indicators.", "tip"),
      spacer(120),

      h2("3.5  Submitting Test Results (Tester)"),
      para("After all sessions are complete, compile the overall result and submit for approval."),
      spacer(80),
      stepBold("From the request detail, ", "ensure all sessions are in Completed status."),
      stepBold("Click 'Submit Results'. ", "The result submission panel opens."),
      stepBold("Fill in the result fields:"),
      bullet("Overall Result — Pass, Fail, Conditional Pass, or Advisory."),
      bullet("Recommendation — brief text explaining the overall finding."),
      bullet("Detailed Remarks — optional narrative describing observations across all sessions."),
      stepBold("Click 'Submit for Approval'. ", "Request status changes to Under Approval."),
      spacer(80),
      noteBox("Once submitted, the tester cannot modify the result. If a correction is needed, the Approver must reject and return the request to In Progress.", "warning"),
      spacer(120),

      h2("3.6  Approving / Rejecting Results (Approver)"),
      para("The Approver (EE TLSS, Department Head, or Org Admin) reviews the submitted result and either approves or rejects it."),
      spacer(80),
      stepBold("Navigate to 'Pending Approval' ", "from the dashboard or Testing menu."),
      stepBold("The list shows all requests in Under Approval status ", "for your organisation."),
      stepBold("Click on a request ", "to open the full detail view."),
      stepBold("Review:"),
      bullet("Session summaries — number of sessions, readings taken, pass/fail per session."),
      bullet("Overall result and recommendation submitted by the tester."),
      bullet("Click 'Preview Report' for the HTML session view, or 'Download PDF' for the full certificate document."),
      stepBold("To Approve: ", "click 'Approve', enter any approval notes, and confirm. Status changes to Completed. PDF is finalised."),
      stepBold("To Reject: ", "click 'Reject', enter a mandatory rejection reason, and confirm. Request returns to In Progress. Tester is notified and can revise and re-submit."),
      spacer(80),
      noteBox("Approved results cannot be modified. If a post-approval correction is needed, raise a new testing request referencing the original.", "important"),
      spacer(120),

      // ──────────────────────────────────────────────────────────────────────
      // 4. FAILURE REGISTRY
      // ──────────────────────────────────────────────────────────────────────
      h1("4. Failure Registry — Direct Submission"),
      para("The Failure Registry module allows authorised field staff to record equipment failures on-the-spot, bypassing the normal tester-assignment flow. Designed for urgent fault documentation during patrols or post-incident investigations."),
      spacer(80),
      noteBox("Permitted roles: Field Staff, Field Tester, AEE, AEE Maintenance, EE TLSS, TA&QC Officer, Originator, Department Head, Test Assigner, Admin, SuperAdmin.", "note"),
      spacer(80),

      h2("4.1  How Failure Registry Differs from Standard Testing"),
      new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: [3400, 2980, 2980],
        rows: [
          new TableRow({ tableHeader: true, children: [
            new TableCell({ borders: mkborders(BLUE_DARK), width: { size: 3400, type: WidthType.DXA },
              shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
              children: [new Paragraph({ children: [new TextRun({ text: "Aspect", font: "Arial", size: 20, bold: true, color: WHITE })] })] }),
            new TableCell({ borders: mkborders(BLUE_DARK), width: { size: 2980, type: WidthType.DXA },
              shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
              children: [new Paragraph({ children: [new TextRun({ text: "Standard Testing", font: "Arial", size: 20, bold: true, color: WHITE })] })] }),
            new TableCell({ borders: mkborders(BLUE_DARK), width: { size: 2980, type: WidthType.DXA },
              shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
              children: [new Paragraph({ children: [new TextRun({ text: "Failure Registry", font: "Arial", size: 20, bold: true, color: WHITE })] })] }),
          ]}),
          ...[
            ["Request number prefix",  "Standard",     "FR-YYYYMMDD-NNNN"],
            ["Tester assignment",      "Required",     "Not required — submitter is recorder"],
            ["Sessions",               "Multiple",     "Recorded at submission time"],
            ["Initial status",         "Draft",        "Directly Under Approval"],
            ["Approval required",      "Yes",          "Yes — same approval queue"],
            ["Typical use",            "Planned tests","Unplanned failure events"],
          ].map(function(r, i) {
            return new TableRow({ children: r.map(function(cell, j) {
              return new TableCell({ borders: mkborders(GRAY_MID),
                width: { size: [3400, 2980, 2980][j], type: WidthType.DXA },
                shading: { fill: i % 2 === 0 ? GRAY_LIGHT : WHITE, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
                children: [new Paragraph({ children: [new TextRun({ text: cell, font: "Arial", size: 20, bold: j === 0, color: j === 0 ? BLUE_DARK : BLACK })] })] });
            })});
          }),
        ],
      }),
      spacer(120),

      h2("4.2  Creating a Failure Registry Record"),
      stepBold("Navigate to 'Failure Registry' ", "from the left menu."),
      stepBold("Click 'New Failure Record'."),
      stepBold("Fill in the form:"),
      bullet("Title — short description of the failure event (e.g. 'Bushing flashover — Bay 3 CB')."),
      bullet("Equipment — search by UEIC or name and select the failed equipment."),
      bullet("Failure Data — template fields: failure mode, visual observations, measurement at fault, cause assessment, immediate action taken."),
      bullet("Overall Result — defaults to Fail; change if the observation is a near-miss or warning."),
      bullet("Remarks — detailed failure narrative."),
      bullet("Priority — set to Urgent for safety-critical failures."),
      stepBold("Click 'Submit Record'. ", "A request number FR-YYYYMMDD-NNNN is assigned and the record enters the Under Approval queue immediately."),
      spacer(80),
      noteBox("Request number format: FR (Failure Registry) + submission date (YYYYMMDD) + four-digit sequence. Example: FR-20260428-0001.", "note"),
      spacer(120),

      h2("4.3  Viewing Your Failure Registry Submissions"),
      stepBold("Navigate to 'Failure Registry'. ", "The list view shows all FR records for your organisation."),
      stepBold("Use the 'My Submissions' toggle ", "to filter down to records you personally created."),
      stepBold("Click on any record ", "to see the full detail including test data, submission time, and current approval status."),
      spacer(120),

      // ──────────────────────────────────────────────────────────────────────
      // 5. TA&QC INSPECTION
      // ──────────────────────────────────────────────────────────────────────
      h1("5. TA&QC Inspection — Direct Submission"),
      para("The Technical Audit & Quality Control (TA&QC) Inspection module allows TA&QC Officers and senior technical staff to log inspection observations directly for management review and archiving."),
      spacer(80),
      noteBox("Permitted roles: TA&QC Officer, AEE Maintenance, EE TLSS, Department Head, Admin, SuperAdmin.", "note"),
      spacer(80),

      h2("5.1  Creating a TA&QC Inspection Record"),
      stepBold("Navigate to 'TA&QC Inspection' ", "from the left menu."),
      stepBold("Click 'New Inspection Record'."),
      stepBold("Fill in the form:"),
      bullet("Title — inspection scope (e.g. '220kV Substation Annual TA&QC Review — Mysuru')."),
      bullet("Equipment — optionally link to specific equipment if the inspection relates to a single asset."),
      bullet("Inspection Data — template fields: checklist items, compliance status per item, observations, photographic evidence references."),
      bullet("Overall Result — defaults to Advisory; change to Conditional Pass if corrective actions are required."),
      bullet("Remarks — narrative summary of findings and recommendations."),
      stepBold("Click 'Submit Record'. ", "A request number TQ-YYYYMMDD-NNNN is assigned and the record enters the Under Approval queue immediately."),
      spacer(80),
      noteBox("Request number format: TQ (TA&QC) + submission date (YYYYMMDD) + four-digit sequence. Example: TQ-20260428-0001.", "note"),
      spacer(120),

      // ──────────────────────────────────────────────────────────────────────
      // 6. PENDING APPROVAL QUEUE
      // ──────────────────────────────────────────────────────────────────────
      h1("6. Pending Approval Queue"),
      para("The Pending Approval queue consolidates all testing requests awaiting a decision — standard test results, Failure Registry records, and TA&QC Inspection records."),
      spacer(80),

      h2("6.1  Accessing the Queue"),
      stepBold("Click 'Pending Approval' ", "in the left navigation menu (visible only to Approver roles)."),
      stepBold("The list displays:"),
      bullet("Request Number — prefix indicates type (FR-, TQ-, or standard)."),
      bullet("Title, Category, Status — all entries show Under Approval."),
      bullet("Submitted By and Submitted At timestamp."),
      stepBold("Use filters ", "to search by request number, filter by category, or sort by date."),
      spacer(120),

      h2("6.2  Approving a Request"),
      stepBold("Click on a request ", "to open the full detail view."),
      stepBold("Review sessions, readings, overall result, and the Recommendation panel."),
      stepBold("Click 'Approve'. ", "Enter approval notes and click Confirm."),
      stepBold("Status changes to Completed. ", "The test result PDF is generated and available for download."),
      spacer(120),

      h2("6.3  Rejecting / Returning a Request"),
      stepBold("Click 'Reject' (or 'Return for Revision')."),
      stepBold("Enter a mandatory rejection reason ", "— this is visible to the submitter."),
      stepBold("Click Confirm. ", "Request is returned to In Progress. Submitter is notified and can revise and re-submit."),
      spacer(120),

      // ──────────────────────────────────────────────────────────────────────
      // 7. REPORTS
      // ──────────────────────────────────────────────────────────────────────
      h1("7. Reports & PDF Download"),

      h2("7.1  Session Preview (HTML)"),
      para("Each test session has an HTML preview that shows all readings in a formatted table. Useful for on-screen review without downloading a file."),
      stepBold("Open a completed test session ", "from the Sessions panel of any request."),
      stepBold("Click 'Preview'. ", "A new browser tab opens showing:"),
      bullet("Session header — session name, date, tester name, equipment UEIC and name."),
      bullet("Readings table — reading number, time, all measurement fields (formatted), pass/fail badge per reading, remarks."),
      bullet("Colour-coded result indicator — green background for Pass, red for Fail, amber for Advisory / Conditional."),
      spacer(120),

      h2("7.2  Full Test Result PDF"),
      para("The test result PDF is a formal document consolidating all sessions into a professional report with SPAN-format reading tables."),
      stepBold("Navigate to a Completed request."),
      stepBold("Click 'Download PDF'. ", "The system generates and downloads the PDF."),
      stepBold("The PDF includes:"),
      bullet("Cover header — KPTCL letterhead, request number, title, equipment UEIC, organisation."),
      bullet("Request details panel — priority, category, submitted by, approved by, approval date."),
      bullet("Sessions summary table — one row per session: name, date, tester."),
      bullet("Readings table — SPAN layout: adjacent cells with identical session values are merged (spanning rows/columns) to reduce repetition and produce a compact, professional layout."),
      bullet("Overall result panel — Pass / Fail / Conditional Pass / Advisory with recommendation text."),
      bullet("Approver sign-off — approver name, date, approval remarks."),
      spacer(80),
      noteBox("PDFs are available only for Completed requests. For Under Approval requests, use the HTML session preview.", "tip"),
      spacer(120),

      // ──────────────────────────────────────────────────────────────────────
      // 8. TROUBLESHOOTING
      // ──────────────────────────────────────────────────────────────────────
      h1("8. Common Issues & Troubleshooting"),
      twoColTable(3000, 6360, ["Issue", "Resolution"], [
        ["Account locked after login failures",
         "Wait 15 minutes for the lock to expire, or ask your administrator to reset the lockout. Field / Lab testers use password Tester123!; admin-level users use admin123. Do not retry more than 5 times."],
        ["Submit button not visible on a request",
         "Only the Originator who created the request can submit it. If the request is already in Submitted or later status, the button is hidden by design."],
        ["Failure Registry 'New Record' not visible",
         "Your account may not have the required role. Contact your Org Admin to verify role assignment (requires Field Staff, AEE, EE TLSS, TA&QC Officer, Originator, or similar)."],
        ["TA&QC Inspection access denied (403 error)",
         "Only TA&QC Officer, AEE Maintenance, EE TLSS, Department Head, and Admin roles may submit TA&QC records. Verify your org role with your administrator."],
        ["Cannot find equipment in search",
         "Equipment must be registered in the SEACMS equipment master first. Ask your Org Admin to add the equipment record."],
        ["PDF download shows 'No template found'",
         "The test result template for this record type has not been configured for your organisation. Contact your system administrator to provision the template."],
        ["Session readings not saving",
         "Ensure all mandatory fields (marked *) are filled. Check your internet connection if the save times out."],
        ["Approval queue shows 0 records",
         "The queue is filtered by organisation. Confirm your account is linked to the correct KPTCL organisation in your profile settings."],
        ["PDF shows sessions but no readings",
         "Ensure readings were saved inside each session (not just that sessions were created). Open each session and verify readings are listed before downloading."],
      ], true),
      spacer(120),

      // ──────────────────────────────────────────────────────────────────────
      // 9. QUICK REFERENCE
      // ──────────────────────────────────────────────────────────────────────
      h1("9. Quick Reference Card"),
      para("Print this section as a one-page cheat sheet to keep at your workstation."),
      spacer(80),

      h2("Request Status Meanings"),
      new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: [2400, 6960],
        rows: [
          new TableRow({ tableHeader: true, children: [
            new TableCell({ borders: mkborders(BLUE_DARK), width: { size: 2400, type: WidthType.DXA },
              shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
              children: [new Paragraph({ children: [new TextRun({ text: "Status", font: "Arial", size: 20, bold: true, color: WHITE })] })] }),
            new TableCell({ borders: mkborders(BLUE_DARK), width: { size: 6960, type: WidthType.DXA },
              shading: { fill: BLUE_DARK, type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
              children: [new Paragraph({ children: [new TextRun({ text: "Meaning", font: "Arial", size: 20, bold: true, color: WHITE })] })] }),
          ]}),
          ...[
            ["Draft",           BLUE_MID,  BLUE_PALE,  "Request saved but not yet submitted for assignment."],
            ["Submitted",       ORANGE,    ORANGE_BG,  "Awaiting assignment to a tester."],
            ["Assigned",        BLUE_DARK, BLUE_PALE,  "Tester nominated; waiting for acceptance."],
            ["Accepted",        GREEN,     GREEN_BG,   "Tester has confirmed the assignment."],
            ["In Progress",     ORANGE,    ORANGE_BG,  "Active testing sessions are being conducted."],
            ["Test Submitted",  BLUE_MID,  BLUE_PALE,  "Tester submitted results; awaiting approver review."],
            ["Under Approval",  ORANGE,    ORANGE_BG,  "Approver is reviewing the result or FR/TQ record."],
            ["Completed",       GREEN,     GREEN_BG,   "Approved and closed. PDF certificate available for download."],
            ["Rejected",        RED,       RED_BG,     "Returned to the submitter for correction and re-submission."],
          ].map(function(r) {
            return new TableRow({ children: [
              new TableCell({ borders: mkborders(GRAY_MID), width: { size: 2400, type: WidthType.DXA },
                shading: { fill: r[2], type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: r[0], font: "Arial", size: 20, bold: true, color: r[1] })] })] }),
              new TableCell({ borders: mkborders(GRAY_MID), width: { size: 6960, type: WidthType.DXA },
                shading: { fill: r[2], type: ShadingType.CLEAR }, margins: { top: 80, bottom: 80, left: 120, right: 120 },
                children: [new Paragraph({ children: [new TextRun({ text: r[3], font: "Arial", size: 20, color: BLACK })] })] }),
            ]});
          }),
        ],
      }),
      spacer(120),

      h2("Request Number Prefixes"),
      bullet("FR-YYYYMMDD-NNNN — Failure Registry direct submission (e.g. FR-20260428-0001)"),
      bullet("TQ-YYYYMMDD-NNNN — TA&QC Inspection direct submission (e.g. TQ-20260428-0001)"),
      bullet("Standard requests — follow the numbering scheme configured for your organisation."),
      spacer(120),

      h2("Key Contacts"),
      bullet("System / Org Admin — orgadmin@kptcl.com"),
      bullet("EE TLSS (Approvals) — ee.tlss@kptcl.com"),
      bullet("TA&QC Officer — taqc.officer@kptcl.com"),
      spacer(120),

      // ──────────────────────────────────────────────────────────────────────
      // APPENDIX A
      // ──────────────────────────────────────────────────────────────────────
      h1("Appendix A — Test Category Descriptions"),
      bullet("Routine / Periodic Testing — scheduled maintenance tests per the KPTCL maintenance schedule."),
      bullet("Special Testing — tests ordered outside the routine schedule due to operational events."),
      bullet("Commissioning — pre-energisation tests for newly installed or refurbished equipment."),
      bullet("Failure Registry — direct submission of equipment failure observations (prefix FR-)."),
      bullet("TA&QC Inspection — direct submission of TA&QC audit observations (prefix TQ-)."),
      bullet("Post-Repair Verification — testing after completion of repair work to confirm restoration."),
      spacer(120),

      // ──────────────────────────────────────────────────────────────────────
      // APPENDIX B — GLOSSARY
      // ──────────────────────────────────────────────────────────────────────
      h1("Appendix B — Glossary"),
      twoColTable(2400, 6960, ["Term", "Definition"], [
        ["BDV",               "Breakdown Voltage — measure of dielectric strength of transformer oil."],
        ["Direct Submission",  "An FR or TQ record created atomically without a prior assignment step, going directly to Under Approval."],
        ["FR",                "Failure Registry — module for recording equipment failure events."],
        ["KPTCL",             "Karnataka Power Transmission Corporation Limited."],
        ["Org Admin",         "Organisational Administrator — full rights within a KPTCL organisation unit."],
        ["Reading",           "A single measurement captured within a test session."],
        ["Recommendation",    "The submitter's conclusion (Pass, Fail, Conditional, Advisory, Retest) for the approver's consideration."],
        ["SEACMS",            "SubStation Equipment & Asset Condition Monitoring System."],
        ["Session",           "A discrete site visit or measurement run associated with a testing request."],
        ["SPAN",              "PDF table layout where adjacent cells with identical values are merged (spanning rows/columns) to reduce repetition and improve readability."],
        ["TA&QC",             "Technical Audit & Quality Control — KPTCL's audit function for equipment compliance."],
        ["TQ",                "TA&QC Inspection — module for recording TA&QC audit observations."],
        ["UEIC",              "Unique Equipment Identification Code — the asset tag assigned to each piece of KPTCL equipment."],
      ], false),
      spacer(240),
      hr(),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 160, after: 80 },
        children: [new TextRun({ text: "End of Document", font: "Arial", size: 20, italics: true, color: GRAY_MID })] }),
      new Paragraph({ alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: "SEACMS User Manual v1.0  |  KPTCL Internal Use Only  |  April 2026", font: "Arial", size: 18, color: GRAY_MID })] }),
    ],
  }],
});

Packer.toBuffer(doc).then(function(buffer) {
  fs.writeFileSync("C:\\Yesu\\CustomerAPI\\Customer-API\\SEACMS_MultiSession_UserManual.docx", buffer);
  console.log("Done! Size: " + Math.round(buffer.length / 1024) + "KB");
}).catch(function(err) {
  console.error("Error:", err.message);
  process.exit(1);
});
